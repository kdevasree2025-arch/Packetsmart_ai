import React, { useState } from 'react';
import { X, Plus, DollarSign } from 'lucide-react';
import { BudgetPacket, Transaction } from '../types/finance';
import { formatCurrency } from '../utils/formatters';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  packets: BudgetPacket[];
  initialPacketId?: string;
  currency: string;
  onSave: (tx: Omit<Transaction, 'id'>) => void;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  packets,
  initialPacketId,
  currency,
  onSave,
}) => {
  const [packetId, setPacketId] = useState(initialPacketId || packets[0]?.id || '');
  const [description, setDescription] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [merchant, setMerchant] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isRecurring, setIsRecurring] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(amountStr);
    if (!description.trim() || isNaN(amount) || amount <= 0 || !packetId) return;

    onSave({
      packetId,
      description: description.trim(),
      amount,
      date,
      category: 'General',
      merchant: merchant.trim() || undefined,
      isRecurring,
    });

    onClose();
  };

  const selectedPacket = packets.find((p) => p.id === packetId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-white">Log Expense into Envelope</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="text-slate-300 block mb-1">Target Envelope</label>
            <select
              value={packetId}
              onChange={(e) => setPacketId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              required
            >
              {packets.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({formatCurrency(p.budget - p.spent, currency)} left)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 block mb-1">Amount ($)</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                required
              />
            </div>
            <div>
              <label className="text-slate-300 block mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-slate-300 block mb-1">Description</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Grocery restock, Uber to office, Blue Bottle coffee"
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              required
            />
          </div>

          <div>
            <label className="text-slate-300 block mb-1">Merchant / Store (Optional)</label>
            <input
              type="text"
              value={merchant}
              onChange={(e) => setMerchant(e.target.value)}
              placeholder="e.g. Whole Foods, Netflix, Shell Gas"
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
            />
          </div>

          <label className="flex items-center gap-2 text-slate-300 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={isRecurring}
              onChange={(e) => setIsRecurring(e.target.checked)}
              className="rounded bg-slate-900 border-slate-800 text-emerald-500 focus:ring-0"
            />
            <span>This is a recurring monthly bill / subscription</span>
          </label>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Expense</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
