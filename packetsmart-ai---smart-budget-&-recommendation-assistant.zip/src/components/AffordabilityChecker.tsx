import React, { useState } from 'react';
import { 
  HelpCircle, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Clock, 
  ArrowRight,
  TrendingDown,
  ShieldCheck,
  Plus
} from 'lucide-react';
import { BudgetPacket, AffordabilityDecision } from '../types/finance';
import { formatCurrency } from '../utils/formatters';

interface AffordabilityCheckerProps {
  packets: BudgetPacket[];
  currency: string;
  monthlyIncome: number;
  onLogPurchase: (packetId: string, description: string, amount: number) => void;
}

export const AffordabilityChecker: React.FC<AffordabilityCheckerProps> = ({
  packets,
  currency,
  monthlyIncome,
  onLogPurchase,
}) => {
  const [itemName, setItemName] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [selectedPacketId, setSelectedPacketId] = useState(packets[0]?.id || '');
  const [isLoading, setIsLoading] = useState(false);
  const [decision, setDecision] = useState<AffordabilityDecision | null>(null);
  const [loggedSuccess, setLoggedSuccess] = useState(false);

  const selectedPacket = packets.find((p) => p.id === selectedPacketId) || packets[0];
  const packetRemaining = selectedPacket ? selectedPacket.budget - selectedPacket.spent : 0;
  const totalAllocated = packets.reduce((s, p) => s + p.budget, 0);
  const totalSpent = packets.reduce((s, p) => s + p.spent, 0);
  const totalRemainingPool = totalAllocated - totalSpent;

  const handleEvaluate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const amount = parseFloat(amountStr);
    if (!itemName.trim() || isNaN(amount) || amount <= 0) return;

    setIsLoading(true);
    setDecision(null);
    setLoggedSuccess(false);

    try {
      const response = await fetch('/api/gemini/affordability', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          itemName: itemName.trim(),
          amount,
          packetId: selectedPacket.id,
          packetName: selectedPacket.name,
          packetRemaining,
          totalRemainingBudget: totalRemainingPool,
          monthlyIncome,
          savingsGoal: 1000,
        }),
      });

      const data = await response.json();
      if (data.decision) {
        setDecision(data.decision);
      }
    } catch (err) {
      console.error('Affordability check failed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPreset = (presetName: string, presetAmount: number, targetPktName: string) => {
    setItemName(presetName);
    setAmountStr(String(presetAmount));
    const matched = packets.find(p => p.name.toLowerCase().includes(targetPktName.toLowerCase()));
    if (matched) setSelectedPacketId(matched.id);
  };

  const handleApproveAndLog = () => {
    if (!decision) return;
    const amount = parseFloat(amountStr);
    onLogPurchase(selectedPacket.id, itemName, amount);
    setLoggedSuccess(true);
  };

  const getVerdictStyle = (verdict: AffordabilityDecision['verdict']) => {
    switch (verdict) {
      case 'YES_AFFORDABLE':
        return {
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
          border: 'border-emerald-800/80',
          bg: 'bg-emerald-950/20',
          textColor: 'text-emerald-400',
          badgeText: 'Fully Covered & Safe',
        };
      case 'YES_WITH_REBALANCE':
        return {
          icon: <AlertTriangle className="w-5 h-5 text-sky-400" />,
          border: 'border-sky-800/80',
          bg: 'bg-sky-950/20',
          textColor: 'text-sky-400',
          badgeText: 'Affordable with Rebalance',
        };
      case 'DELAY_RECOMMENDED':
        return {
          icon: <Clock className="w-5 h-5 text-amber-400" />,
          border: 'border-amber-800/80',
          bg: 'bg-amber-950/20',
          textColor: 'text-amber-400',
          badgeText: 'Wait 48-Hours or Next Cycle',
        };
      case 'NOT_RECOMMENDED':
      default:
        return {
          icon: <XCircle className="w-5 h-5 text-rose-400" />,
          border: 'border-rose-800/80',
          bg: 'bg-rose-950/20',
          textColor: 'text-rose-400',
          badgeText: 'Derails Budget Envelopes',
        };
    }
  };

  return (
    <div className="space-y-5">
      {/* Intro Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider font-mono">
          <HelpCircle className="w-4 h-4" />
          <span>Real-Time Purchasing Oracle</span>
        </div>
        <h2 className="text-xl font-bold font-display text-white mt-1">
          "Can I Afford This?" Instant Decision Engine
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Before pulling out your credit card, ask PacketSmart AI. It calculates your exact envelope cushion, remaining days in the cycle, and opportunity cost.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Form Column */}
        <div className="lg:col-span-5 p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
          <form onSubmit={handleEvaluate} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                What are you thinking of buying?
              </label>
              <input
                type="text"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="e.g. Breville Espresso Machine, Weekend AirBnb..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Price / Cost
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-500 text-sm font-mono">
                    $
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={amountStr}
                    onChange={(e) => setAmountStr(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-2.5 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Target Envelope
                </label>
                <select
                  value={selectedPacketId}
                  onChange={(e) => setSelectedPacketId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
                >
                  {packets.map((p) => {
                    const rem = p.budget - p.spent;
                    return (
                      <option key={p.id} value={p.id}>
                        {p.name} ({formatCurrency(rem, currency)} left)
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>

            {/* Envelope Context Preview */}
            {selectedPacket && (
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">Available in {selectedPacket.name}:</span>
                <span className={`font-mono font-bold tabular-nums ${packetRemaining >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {formatCurrency(packetRemaining, currency)}
                </span>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading || !itemName || !amountStr}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-medium text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isLoading ? 'Consulting Gemini Model...' : 'Calculate Affordability'}</span>
            </button>
          </form>

          {/* Quick Preset Examples */}
          <div className="pt-3 border-t border-slate-800/80">
            <span className="text-[11px] text-slate-400 block mb-2">Try quick simulations:</span>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickPreset('Espresso Machine', 189, 'dining')}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Espresso Machine ($189)
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('Upscale Bistro Dinner', 75, 'dining')}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Dinner ($75)
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('Noise-Canceling Headphones', 299, 'tech')}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Headphones ($299)
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('Weekend Getaway Hotel', 340, 'fun')}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Getaway ($340)
              </button>
            </div>
          </div>
        </div>

        {/* Results Column */}
        <div className="lg:col-span-7">
          {decision ? (
            <div className={`p-5 rounded-2xl border ${getVerdictStyle(decision.verdict).border} ${getVerdictStyle(decision.verdict).bg} space-y-4`}>
              
              {/* Verdict Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  {getVerdictStyle(decision.verdict).icon}
                  <div>
                    <span className="text-xs font-mono uppercase tracking-wider text-slate-400 block">
                      {getVerdictStyle(decision.verdict).badgeText}
                    </span>
                    <h3 className={`text-lg font-bold font-display ${getVerdictStyle(decision.verdict).textColor}`}>
                      {decision.verdictTitle}
                    </h3>
                  </div>
                </div>

                {/* Score */}
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-mono">
                    Affordability Score
                  </span>
                  <span className="text-xl font-bold font-mono text-white tabular-nums">
                    {decision.impactScore}<span className="text-xs text-slate-500">/100</span>
                  </span>
                </div>
              </div>

              {/* Explanation */}
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3.5 rounded-xl border border-slate-800/80">
                {decision.explanation}
              </p>

              {/* Mathematical Aftermath */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">Envelope After Purchase:</span>
                  <span className={`font-mono font-bold text-sm tabular-nums ${decision.packetAftermath >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {formatCurrency(decision.packetAftermath, currency)}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">Purchase Cost:</span>
                  <span className="font-mono font-bold text-sm text-white tabular-nums">
                    {formatCurrency(parseFloat(amountStr) || 0, currency)}
                  </span>
                </div>
              </div>

              {/* Smart Strategy */}
              <div className="space-y-2 text-xs">
                <div className="flex items-start gap-2 text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-medium">Smart Strategy:</strong>
                    <span>{decision.smartStrategy}</span>
                  </div>
                </div>

                {decision.alternativeTip && (
                  <div className="flex items-start gap-2 text-slate-400 text-[11px] pt-2 border-t border-slate-800/60">
                    <TrendingDown className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                    <span>Alternative: {decision.alternativeTip}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  {loggedSuccess ? 'Successfully added to ledger' : 'Decision generated by Gemini'}
                </span>

                {loggedSuccess ? (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Logged to Transactions</span>
                  </div>
                ) : (
                  <button
                    onClick={handleApproveAndLog}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg shadow-sm transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Approve & Log Purchase Now</span>
                  </button>
                )}
              </div>

            </div>
          ) : (
            <div className="h-full min-h-[300px] rounded-2xl border border-dashed border-slate-800 bg-slate-900/20 p-6 flex flex-col items-center justify-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-3">
                <Sparkles className="w-6 h-6 text-emerald-400/60" />
              </div>
              <h3 className="text-sm font-semibold text-slate-300">
                Ready for Affordability Assessment
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Enter any impulse buy, gadget, subscription, or night out. PacketSmart AI tests it against your live envelope balance and savings goals.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
