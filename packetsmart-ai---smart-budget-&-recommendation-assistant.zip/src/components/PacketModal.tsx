import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';
import { BudgetPacket, CategoryType } from '../types/finance';

interface PacketModalProps {
  isOpen: boolean;
  onClose: () => void;
  packetToEdit?: BudgetPacket | null;
  onSave: (packetData: Omit<BudgetPacket, 'id' | 'spent'> & { id?: string }) => void;
}

const AVAILABLE_ICONS = [
  'Home', 'ShoppingBag', 'Utensils', 'Car', 'Zap', 'Smartphone', 'Sparkles',
  'HeartPulse', 'Shield', 'Plane', 'Laptop', 'PiggyBank', 'Coffee', 'Music',
  'Film', 'Briefcase', 'GraduationCap', 'Shirt', 'BookOpen', 'Dumbbell'
];

export const PacketModal: React.FC<PacketModalProps> = ({
  isOpen,
  onClose,
  packetToEdit,
  onSave,
}) => {
  const [name, setName] = useState('');
  const [budget, setBudget] = useState('300');
  const [categoryType, setCategoryType] = useState<CategoryType>('needs');
  const [icon, setIcon] = useState('ShoppingBag');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (packetToEdit) {
      setName(packetToEdit.name);
      setBudget(String(packetToEdit.budget));
      setCategoryType(packetToEdit.categoryType);
      setIcon(packetToEdit.icon);
      setDescription(packetToEdit.description);
    } else {
      setName('');
      setBudget('300');
      setCategoryType('needs');
      setIcon('ShoppingBag');
      setDescription('');
    }
  }, [packetToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !budget) return;

    onSave({
      id: packetToEdit ? packetToEdit.id : undefined,
      name: name.trim(),
      budget: parseFloat(budget) || 0,
      categoryType,
      icon,
      color: 'emerald',
      description: description.trim() || `${name} envelope allocation`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-white">
            {packetToEdit ? 'Edit Budget Envelope' : 'Create Budget Packet'}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="text-slate-300 block mb-1">Packet Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Pet Care, Hobbies, Coffee & Bakeries"
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 block mb-1">Monthly Cap ($)</label>
              <input
                type="number"
                step="1"
                min="0"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                required
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1">Bucket Category</label>
              <select
                value={categoryType}
                onChange={(e) => setCategoryType(e.target.value as CategoryType)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              >
                <option value="needs">Needs (Essential 50%)</option>
                <option value="wants">Wants (Discretionary 30%)</option>
                <option value="savings">Savings (Growth 20%)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-slate-300 block mb-1">Envelope Icon</label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1.5 bg-slate-900 rounded-lg border border-slate-800">
              {AVAILABLE_ICONS.map((ic) => (
                <button
                  type="button"
                  key={ic}
                  onClick={() => setIcon(ic)}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                    icon === ic
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-slate-300 block mb-1">Description / Guidelines</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What belongs in this envelope?"
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save Envelope</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
