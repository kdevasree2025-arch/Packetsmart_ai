import React, { useState } from 'react';
import { X, Sparkles, Check, ArrowRight } from 'lucide-react';
import { BudgetPacket } from '../types/finance';
import { formatCurrency } from '../utils/formatters';
import { DynamicIcon } from './DynamicIcon';

interface PlanGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  monthlyIncome: number;
  currency: string;
  onAdoptPlan: (newPackets: BudgetPacket[]) => void;
}

export const PlanGeneratorModal: React.FC<PlanGeneratorModalProps> = ({
  isOpen,
  onClose,
  monthlyIncome,
  currency,
  onAdoptPlan,
}) => {
  const [strategy, setStrategy] = useState('Balanced 50/30/20');
  const [priorities, setPriorities] = useState('Build a solid 6-month emergency buffer and curb restaurant spending');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedPackets, setGeneratedPackets] = useState<BudgetPacket[] | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setGeneratedPackets(null);

    try {
      const response = await fetch('/api/gemini/generate-packets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          monthlyIncome,
          strategy,
          priorities,
        }),
      });

      const data = await response.json();
      if (data.packets && Array.isArray(data.packets)) {
        // assign zero spent to start fresh
        const formatted = data.packets.map((p: any) => ({
          ...p,
          spent: 0,
        }));
        setGeneratedPackets(formatted);
      }
    } catch (err) {
      console.error('Plan generation failed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    if (!generatedPackets) return;
    onAdoptPlan(generatedPackets);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-xl p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-sm text-white">Smart AI Packet Budget Plan Generator</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400">
          Let Gemini design a customized zero-based packet envelope structure tailored to your monthly income of <strong className="text-white font-mono">{formatCurrency(monthlyIncome, currency)}</strong>.
        </p>

        {!generatedPackets ? (
          <form onSubmit={handleGenerate} className="space-y-3.5 text-xs">
            <div>
              <label className="text-slate-300 block mb-1">Budgeting Philosophy</label>
              <select
                value={strategy}
                onChange={(e) => setStrategy(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
              >
                <option value="Balanced 50/30/20">Balanced 50/30/20 (Needs 50%, Wants 30%, Savings 20%)</option>
                <option value="Aggressive Wealth Builder">Aggressive FIRE (Needs 45%, Wants 15%, Savings 40%)</option>
                <option value="Lean Student / Early Career">Lean / Early Career (Needs 60%, Fun 25%, Emergency 15%)</option>
                <option value="Zero-Based Mindful Living">Zero-Based Mindful Living (Custom Envelope Precision)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 block mb-1">Personal Lifestyle & Priorities</label>
              <textarea
                value={priorities}
                onChange={(e) => setPriorities(e.target.value)}
                placeholder="e.g. Living in high cost of living city, have pet dog, prioritize fitness, want to travel in 6 months..."
                rows={3}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-semibold rounded-lg flex items-center gap-1.5"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>{isLoading ? 'Designing Envelopes with Gemini...' : 'Generate Personalized Plan'}</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between text-slate-300">
              <span className="font-semibold text-white">Generated Plan ({generatedPackets.length} Envelopes)</span>
              <span className="font-mono text-emerald-400 font-bold">
                Total: {formatCurrency(generatedPackets.reduce((s, p) => s + p.budget, 0), currency)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto p-1">
              {generatedPackets.map((pkt) => (
                <div key={pkt.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center shrink-0">
                      <DynamicIcon name={pkt.icon} className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-white font-medium block truncate">{pkt.name}</span>
                      <span className="text-[10px] text-slate-400 capitalize">{pkt.categoryType}</span>
                    </div>
                  </div>
                  <span className="font-mono font-bold text-slate-200 tabular-nums shrink-0">
                    {formatCurrency(pkt.budget, currency)}
                  </span>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-800">
              <button
                onClick={() => setGeneratedPackets(null)}
                className="text-slate-400 hover:text-white"
              >
                Back / Regenerate
              </button>
              <button
                onClick={handleApply}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg flex items-center gap-1.5 shadow-md"
              >
                <Check className="w-4 h-4" />
                <span>Adopt Plan & Set Envelopes</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
