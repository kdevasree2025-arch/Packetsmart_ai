import React from 'react';
import * as Icons from 'lucide-react';

interface DynamicIconProps {
  name: string;
  className?: string;
  size?: number;
}

export const DynamicIcon: React.FC<DynamicIconProps> = ({ name, className = 'w-5 h-5', size = 20 }) => {
  // Normalize lookup
  const cleanName = name.trim();
  // @ts-ignore
  const IconComponent = Icons[cleanName] || Icons[cleanName.charAt(0).toUpperCase() + cleanName.slice(1)] || Icons.Folder;

  return <IconComponent className={className} size={size} />;
};
