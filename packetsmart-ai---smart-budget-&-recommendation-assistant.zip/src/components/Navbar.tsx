import React from 'react';
import { 
  Layers, 
  Plus, 
  Sparkles, 
  MessageSquareCode, 
  RotateCcw,
  SlidersHorizontal,
  DollarSign
} from 'lucide-react';
import { CURRENCY_SYMBOLS } from '../utils/formatters';

interface NavbarProps {
  currency: string;
  onCurrencyChange: (curr: string) => void;
  monthlyIncome: number;
  onEditIncome: () => void;
  onOpenNewPacket: () => void;
  onOpenNewTransaction: () => void;
  onOpenPlanGenerator: () => void;
  onToggleAiAdvisor: () => void;
  isAiAdvisorOpen: boolean;
  onResetData: () => void;
  activeView: 'dashboard' | 'products' | 'affordability' | 'recommendations' | 'transactions' | 'goals';
  setActiveView: (view: 'dashboard' | 'products' | 'affordability' | 'recommendations' | 'transactions' | 'goals') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currency,
  onCurrencyChange,
  monthlyIncome,
  onEditIncome,
  onOpenNewPacket,
  onOpenNewTransaction,
  onOpenPlanGenerator,
  onToggleAiAdvisor,
  isAiAdvisorOpen,
  onResetData,
  activeView,
  setActiveView,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Brand */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setActiveView('dashboard')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-400 p-[1px] shadow-sm shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-slate-950 rounded-[11px] flex items-center justify-center text-emerald-400">
                  <Layers className="w-5 h-5" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-display font-bold text-base tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                    PacketSmart
                  </span>
                  <span className="text-[10px] font-semibold tracking-wider uppercase text-emerald-400 font-mono">
                    AI
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-none">Smart Packet Budgeting</p>
              </div>
            </button>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 ml-6 border-l border-slate-800/80 pl-6">
              <button
                onClick={() => setActiveView('products')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                  activeView === 'products'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <span>Product Recommender</span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              </button>
              <button
                onClick={() => setActiveView('dashboard')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                  activeView === 'dashboard'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Packets & Budget
              </button>
              <button
                onClick={() => setActiveView('recommendations')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                  activeView === 'recommendations'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <span>AI Recommendations</span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              </button>
              <button
                onClick={() => setActiveView('affordability')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                  activeView === 'affordability'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Can I Afford It?
              </button>
              <button
                onClick={() => setActiveView('transactions')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                  activeView === 'transactions'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Transactions
              </button>
              <button
                onClick={() => setActiveView('goals')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                  activeView === 'goals'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Savings Goals
              </button>
            </nav>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Income Badge / Quick Edit */}
            <button
              onClick={onEditIncome}
              title="Click to change monthly income"
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-300 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <span className="text-slate-500">Income:</span>
              <span className="font-semibold text-white font-mono tabular-nums">
                {CURRENCY_SYMBOLS[currency] || '$'}{monthlyIncome.toLocaleString()}
              </span>
              <SlidersHorizontal className="w-3 h-3 text-slate-400 ml-0.5" />
            </button>

            {/* Currency Selector */}
            <select
              value={currency}
              onChange={(e) => onCurrencyChange(e.target.value)}
              className="bg-slate-900 text-slate-300 text-xs font-medium rounded-lg border border-slate-800 px-2 py-1.5 focus:outline-none focus:border-emerald-500 transition-colors"
            >
              {Object.keys(CURRENCY_SYMBOLS).map((curr) => (
                <option key={curr} value={curr}>
                  {curr} ({CURRENCY_SYMBOLS[curr]})
                </option>
              ))}
            </select>

            {/* AI Advisor Drawer Toggle */}
            <button
              onClick={onToggleAiAdvisor}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                isAiAdvisorOpen
                  ? 'bg-emerald-500 text-slate-950 font-semibold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-900 text-emerald-400 border border-emerald-500/30 hover:bg-slate-800 hover:border-emerald-500/60'
              }`}
            >
              <MessageSquareCode className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Ask AI Advisor</span>
              <span className="sm:hidden">Advisor</span>
            </button>

            {/* Quick Log Expense Button */}
            <button
              onClick={onOpenNewTransaction}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg shadow-sm shadow-emerald-950 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Log Expense</span>
              <span className="sm:hidden">Expense</span>
            </button>

            {/* Reset Demo State button */}
            <button
              onClick={onResetData}
              title="Reset to default sample data"
              className="p-1.5 text-slate-500 hover:text-slate-300 rounded-lg hover:bg-slate-900 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden border-t border-slate-800/80 px-4 py-2 flex items-center gap-1 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveView('products')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
            activeView === 'products' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Product Recommender
        </button>
        <button
          onClick={() => setActiveView('dashboard')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
            activeView === 'dashboard' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Packets
        </button>
        <button
          onClick={() => setActiveView('recommendations')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
            activeView === 'recommendations' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Recommendations
        </button>
        <button
          onClick={() => setActiveView('affordability')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
            activeView === 'affordability' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Afford It?
        </button>
        <button
          onClick={() => setActiveView('transactions')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
            activeView === 'transactions' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Transactions
        </button>
        <button
          onClick={() => setActiveView('goals')}
          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
            activeView === 'goals' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Goals
        </button>
      </div>
    </header>
  );
};
