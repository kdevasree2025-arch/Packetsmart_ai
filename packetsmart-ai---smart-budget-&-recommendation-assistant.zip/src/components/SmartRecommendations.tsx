import React, { useState } from 'react';
import { 
  Sparkles, 
  RefreshCw, 
  ArrowRightLeft, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingDown, 
  Flag,
  ArrowRight
} from 'lucide-react';
import { Recommendation, BudgetPacket, Transaction } from '../types/finance';
import { formatCurrency } from '../utils/formatters';

interface SmartRecommendationsProps {
  recommendations: Recommendation[];
  onRefreshRecommendations: () => Promise<void>;
  isLoading: boolean;
  onApplyRecommendation: (rec: Recommendation) => void;
  currency: string;
}

export const SmartRecommendations: React.FC<SmartRecommendationsProps> = ({
  recommendations,
  onRefreshRecommendations,
  isLoading,
  onApplyRecommendation,
  currency,
}) => {
  const [filterType, setFilterType] = useState<string>('all');

  const totalPotentialSavings = recommendations
    .filter(r => !r.applied)
    .reduce((sum, r) => sum + (r.potentialMonthlySavings || 0), 0);

  const filtered = recommendations.filter(r => {
    if (filterType === 'all') return true;
    return r.type === filterType;
  });

  const getIconForType = (type: Recommendation['type']) => {
    switch (type) {
      case 'rebalance':
        return <ArrowRightLeft className="w-4 h-4 text-sky-400" />;
      case 'leak_detected':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'saving_hack':
        return <TrendingDown className="w-4 h-4 text-emerald-400" />;
      case 'milestone':
        return <Flag className="w-4 h-4 text-purple-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-emerald-950/20 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider font-mono">
            <Sparkles className="w-4 h-4" />
            <span>AI Budget & Spending Intelligence</span>
          </div>
          <h2 className="text-xl font-bold font-display text-white mt-1">
            Smart Recommendations
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Gemini continuously scans your envelope allocations, recurring bills, and merchant velocities to find effortless ways to stretch your income.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-right">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-mono">Potential Savings</span>
            <span className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
              {formatCurrency(totalPotentialSavings, currency)}<span className="text-xs text-slate-500 font-normal">/mo</span>
            </span>
          </div>

          <button
            onClick={() => onRefreshRecommendations()}
            disabled={isLoading}
            className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{isLoading ? 'Analyzing Envelopes...' : 'Refresh AI Analysis'}</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg w-fit">
        <button
          onClick={() => setFilterType('all')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
            filterType === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Insights ({recommendations.length})
        </button>
        <button
          onClick={() => setFilterType('rebalance')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
            filterType === 'rebalance' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Rebalances
        </button>
        <button
          onClick={() => setFilterType('leak_detected')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
            filterType === 'leak_detected' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Subscription Leaks
        </button>
        <button
          onClick={() => setFilterType('saving_hack')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
            filterType === 'saving_hack' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Savings Hacks
        </button>
      </div>

      {/* Recommendations Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filtered.map((rec) => {
          return (
            <div
              key={rec.id}
              className={`p-4 rounded-xl border transition-all duration-200 flex flex-col justify-between ${
                rec.applied
                  ? 'bg-slate-900/30 border-slate-800/50 opacity-60'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Quiet Unboxed Metadata */}
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <div className="flex items-center gap-2">
                    {getIconForType(rec.type)}
                    <span className="capitalize">{rec.type.replace('_', ' ')}</span>
                    <span aria-hidden="true">·</span>
                    <span className={`${
                      rec.priority === 'high' ? 'text-rose-400 font-medium' : 'text-slate-400'
                    }`}>
                      {rec.priority} Priority
                    </span>
                    {rec.packetName && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-300">{rec.packetName}</span>
                      </>
                    )}
                  </div>

                  {rec.potentialMonthlySavings > 0 && (
                    <span className="font-mono text-emerald-400 font-semibold tabular-nums">
                      +{formatCurrency(rec.potentialMonthlySavings, currency)}/mo
                    </span>
                  )}
                </div>

                <h3 className="font-semibold text-sm text-white tracking-tight leading-snug">
                  {rec.title}
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  {rec.description}
                </p>
              </div>

              {/* Action Strip */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <div className="text-[11px] text-slate-400">
                  {rec.applied ? (
                    <span className="flex items-center gap-1 text-emerald-400 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Applied to Budget
                    </span>
                  ) : (
                    <span>Suggested Action</span>
                  )}
                </div>

                {!rec.applied && (
                  <button
                    onClick={() => onApplyRecommendation(rec)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded-lg border border-slate-700 hover:border-slate-600 transition-colors"
                  >
                    <span>{rec.suggestedAction}</span>
                    <ArrowRight className="w-3 h-3 text-emerald-400" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
