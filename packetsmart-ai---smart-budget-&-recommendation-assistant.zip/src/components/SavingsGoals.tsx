import React, { useState } from 'react';
import { 
  PiggyBank, 
  Plus, 
  Target, 
  Calendar, 
  ShieldCheck, 
  ArrowUpRight, 
  CheckCircle2,
  Trash2
} from 'lucide-react';
import { SavingsGoal, BudgetPacket } from '../types/finance';
import { formatCurrency } from '../utils/formatters';
import { DynamicIcon } from './DynamicIcon';

interface SavingsGoalsProps {
  goals: SavingsGoal[];
  packets: BudgetPacket[];
  currency: string;
  onAddGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  onDepositToGoal: (goalId: string, amount: number, sourcePacketId?: string) => void;
  onDeleteGoal: (goalId: string) => void;
}

export const SavingsGoals: React.FC<SavingsGoalsProps> = ({
  goals,
  packets,
  currency,
  onAddGoal,
  onDepositToGoal,
  onDeleteGoal,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [activeGoalId, setActiveGoalId] = useState<string | null>(null);

  // New goal form
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [currentAmount, setCurrentAmount] = useState('0');
  const [targetDate, setTargetDate] = useState('');
  const [icon, setIcon] = useState('Target');

  // Deposit form
  const [depositAmount, setDepositAmount] = useState('100');
  const [sourcePacketId, setSourcePacketId] = useState(packets[0]?.id || '');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !targetAmount) return;

    onAddGoal({
      name: name.trim(),
      targetAmount: parseFloat(targetAmount) || 0,
      currentAmount: parseFloat(currentAmount) || 0,
      targetDate: targetDate || '2026-12-31',
      icon,
    });

    setIsModalOpen(false);
    setName('');
    setTargetAmount('');
    setCurrentAmount('0');
  };

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGoalId || !depositAmount) return;
    onDepositToGoal(activeGoalId, parseFloat(depositAmount), sourcePacketId);
    setIsDepositModalOpen(false);
    setActiveGoalId(null);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-lg font-bold font-display text-white">
            Savings Targets & Milestones
          </h2>
          <span className="text-xs text-slate-400">
            Envelopes working towards your future wealth
          </span>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg shadow-sm transition-colors cursor-pointer w-fit"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Target Goal</span>
        </button>
      </div>

      {/* Grid of Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {goals.map((goal) => {
          const percent = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
          const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);

          return (
            <div
              key={goal.id}
              className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                      <DynamicIcon name={goal.icon} className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm text-white tracking-tight">
                        {goal.name}
                      </h3>
                      {/* Quiet Unboxed Metadata */}
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                        <span>Target: {goal.targetDate}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteGoal(goal.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs text-slate-400">Accumulated:</span>
                    <span className="text-base font-bold font-mono text-emerald-400 tabular-nums">
                      {formatCurrency(goal.currentAmount, currency)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
                    <span>
                      Target: <strong className="text-slate-200 font-mono">{formatCurrency(goal.targetAmount, currency)}</strong>
                    </span>
                    <span>
                      Remaining: <strong className="text-slate-200 font-mono">{formatCurrency(remaining, currency)}</strong>
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2.5">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1">
                    <span>{percent}% reached</span>
                    {percent >= 100 && (
                      <span className="text-emerald-400 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Fully Funded!
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Deposit Action */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-end">
                <button
                  onClick={() => {
                    setActiveGoalId(goal.id);
                    setIsDepositModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3 h-3 text-emerald-400" />
                  <span>Deposit Funds</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* New Goal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <h3 className="font-bold text-sm text-white">Create New Savings Target</h3>
            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1">Goal Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Down Payment, Summer Holiday, Car Fund"
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1">Target Amount ($)</label>
                  <input
                    type="number"
                    step="1"
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(e.target.value)}
                    placeholder="5000"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1">Starting Balance ($)</label>
                  <input
                    type="number"
                    step="1"
                    value={currentAmount}
                    onChange={(e) => setCurrentAmount(e.target.value)}
                    placeholder="0"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Target Completion Date</label>
                <input
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deposit to Goal Modal */}
      {isDepositModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <h3 className="font-bold text-sm text-white">Deposit to Savings Target</h3>
            <form onSubmit={handleDeposit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1">Deposit Amount ($)</label>
                <input
                  type="number"
                  step="1"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Source Envelope (Optional)</label>
                <select
                  value={sourcePacketId}
                  onChange={(e) => setSourcePacketId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
                >
                  {packets.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({formatCurrency(p.budget - p.spent, currency)} free)
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsDepositModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg"
                >
                  Confirm Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
