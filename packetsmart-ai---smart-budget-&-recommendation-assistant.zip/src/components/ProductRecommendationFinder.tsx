import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  ArrowRight, 
  History, 
  Trash2, 
  RefreshCw,
  SlidersHorizontal,
  ChevronDown
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface RecommendedProduct {
  product_name: string;
  estimated_price: number;
  budget_status: 'Within Budget' | 'Slightly Above Budget' | 'Over Budget' | string;
  remaining_budget: number;
  features: string[];
  pros: string[];
  cons: string[];
  reason: string;
  alternative: string;
}

interface SearchHistoryItem {
  id: number;
  created_at: string;
  budget: number;
  category: string;
  requirements: string;
  brand_preference?: string;
  recommendations: {
    recommendations: RecommendedProduct[];
  };
}

const CATEGORIES = [
  'Smartphones',
  'Laptops',
  'Headphones',
  'Smart Watches',
  'Cameras',
  'Tablets',
  'Gaming Accessories',
  'Other',
];

export const ProductRecommendationFinder: React.FC<{ currency: string }> = ({ currency }) => {
  const [budget, setBudget] = useState('500');
  const [category, setCategory] = useState('Smartphones');
  const [requirements, setRequirements] = useState('Looking for great battery life, crisp camera, and durable daily build');
  const [brandPreference, setBrandPreference] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeResults, setActiveResults] = useState<{
    budget: number;
    category: string;
    requirements: string;
    brand_preference?: string;
    recommendations: RecommendedProduct[];
    fallback_notice?: string;
  } | null>(null);

  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Fetch search history
  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/history');
      const data = await res.json();
      if (data.success && Array.isArray(data.history)) {
        setHistory(data.history);
      }
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numBudget = parseFloat(budget);

    if (isNaN(numBudget) || numBudget <= 0) {
      setErrorMsg('Please enter a valid budget greater than $0.');
      return;
    }
    if (!category) {
      setErrorMsg('Please select a product category.');
      return;
    }
    if (!requirements.trim()) {
      setErrorMsg('Please provide your requirements or use-case.');
      return;
    }

    setErrorMsg('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          budget: numBudget,
          category,
          requirements: requirements.trim(),
          brand_preference: brandPreference.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success && data.data) {
        setActiveResults(data.data);
        fetchHistory(); // refresh history
      } else {
        setErrorMsg(data.errors ? data.errors.join(' ') : (data.error || 'Failed to generate recommendations.'));
      }
    } catch (err) {
      setErrorMsg('Network error connecting to PacketSmart AI.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteHistory = async (id: number) => {
    try {
      const res = await fetch(`/api/history/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setHistory((prev) => prev.filter((item) => item.id !== id));
      }
    } catch (e) {
      console.error('Delete failed', e);
    }
  };

  const getStatusBadge = (status: string) => {
    if (status === 'Within Budget') {
      return (
        <span className="text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded text-xs font-semibold">
          ✓ Within Budget
        </span>
      );
    }
    if (status === 'Slightly Above Budget') {
      return (
        <span className="text-amber-400 bg-amber-950/60 border border-amber-800/80 px-2 py-0.5 rounded text-xs font-semibold">
          ⚠ Slightly Above
        </span>
      );
    }
    return (
      <span className="text-rose-400 bg-rose-950/60 border border-rose-800/80 px-2 py-0.5 rounded text-xs font-semibold">
        ✕ Over Budget
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-semibold uppercase tracking-wider text-emerald-400">
            <Sparkles className="w-4 h-4" />
            <span>AI Budget & Product Recommendation Assistant</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-white mt-1">
            Smart Product Recommender
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Input your ceiling budget, select a category, and specify what matters to you. PacketSmart AI compares real market choices with strict budget arithmetic.
          </p>
        </div>

        <button
          onClick={() => setShowHistory(!showHistory)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors cursor-pointer w-fit"
        >
          <History className="w-3.5 h-3.5 text-emerald-400" />
          <span>{showHistory ? 'Hide History' : `History (${history.length})`}</span>
        </button>
      </div>

      {/* History Slide-Down View */}
      {showHistory && (
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-xs text-white uppercase tracking-wider font-mono">
              Previous Search History ({history.length})
            </h3>
            <span className="text-[11px] text-slate-500">Stored in database</span>
          </div>

          {history.length === 0 ? (
            <p className="text-xs text-slate-500 py-2">No previous searches recorded yet.</p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {history.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{item.category}</span>
                      <span className="text-slate-500">·</span>
                      <span className="text-emerald-400 font-mono font-medium">${item.budget}</span>
                      <span className="text-slate-500">·</span>
                      <span className="text-slate-400 text-[11px]">{item.created_at}</span>
                    </div>
                    <p className="text-slate-400 text-[11px] truncate mt-0.5">"{item.requirements}"</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        setActiveResults({
                          budget: item.budget,
                          category: item.category,
                          requirements: item.requirements,
                          brand_preference: item.brand_preference,
                          recommendations: item.recommendations?.recommendations || [],
                        });
                        setShowHistory(false);
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors"
                    >
                      View
                    </button>
                    <button
                      onClick={() => handleDeleteHistory(item.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Main Request Form */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Budget */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Available Budget ($ USD) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-slate-500 font-mono text-sm">$</span>
                <input
                  type="number"
                  step="1"
                  min="1"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  placeholder="500"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-2 text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Product Category <span className="text-rose-400">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Requirements */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              User Requirements, Specifications & Preferences <span className="text-rose-400">*</span>
            </label>
            <textarea
              value={requirements}
              onChange={(e) => setRequirements(e.target.value)}
              placeholder="e.g. Needs high battery life, good low-light camera for travel, lightweight for daily transit..."
              rows={2}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Optional Brand */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Brand Preference <span className="text-slate-500 text-[11px]">(Optional)</span>
              </label>
              <input
                type="text"
                value={brandPreference}
                onChange={(e) => setBrandPreference(e.target.value)}
                placeholder="e.g. Sony, Apple, Samsung, Lenovo (or empty for any)"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer h-[38px]"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span>{isLoading ? 'Formulating Recommendations...' : 'Get Smart Recommendations'}</span>
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/80 text-rose-300 text-xs">
              {errorMsg}
            </div>
          )}
        </form>
      </div>

      {/* Active Results Display */}
      {activeResults && (
        <div className="space-y-6 pt-2">
          {/* Summary Banner */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-400 block">
                Recommendation Results
              </span>
              <h2 className="text-lg font-bold text-white font-display">
                {activeResults.category} under {formatCurrency(activeResults.budget, currency)}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">"{activeResults.requirements}"</p>
            </div>

            {activeResults.brand_preference && (
              <span className="text-xs text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 self-start sm:self-auto">
                Brand: <strong className="text-white">{activeResults.brand_preference}</strong>
              </span>
            )}
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeResults.recommendations.map((item, idx) => {
              const diff = item.remaining_budget;
              const isPositive = diff >= 0;

              return (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Top Row: Title, Status */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="font-semibold text-sm text-white tracking-tight leading-snug">
                        {item.product_name}
                      </h3>
                      {getStatusBadge(item.budget_status)}
                    </div>

                    {/* Price and Budget Difference */}
                    <div className="flex items-baseline justify-between pt-1 pb-2 border-b border-slate-800/80">
                      <div>
                        <span className="text-xs text-slate-400">Est. Price: </span>
                        <span className="text-base font-bold font-mono text-emerald-400 tabular-nums">
                          {formatCurrency(item.estimated_price, currency)}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">Difference:</span>
                        <span
                          className={`font-mono text-xs font-semibold tabular-nums ${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? `+${formatCurrency(diff, currency)} surplus` : `-${formatCurrency(Math.abs(diff), currency)} over`}
                        </span>
                      </div>
                    </div>

                    {/* Features */}
                    <div className="mt-3">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                        Key Features
                      </span>
                      <ul className="text-xs text-slate-300 space-y-1">
                        {item.features.map((feat, fIdx) => (
                          <li key={fIdx} className="flex items-start gap-1.5">
                            <span className="text-emerald-400 font-bold shrink-0">·</span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Pros & Cons */}
                    <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800/80 text-[11px]">
                      <div>
                        <span className="font-semibold text-emerald-400 block mb-1">Advantages</span>
                        <ul className="text-slate-400 space-y-1">
                          {item.pros.map((p, pIdx) => (
                            <li key={pIdx}>+ {p}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <span className="font-semibold text-rose-400 block mb-1">Limitations</span>
                        <ul className="text-slate-400 space-y-1">
                          {item.cons.map((c, cIdx) => (
                            <li key={cIdx}>- {c}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Why it matches */}
                    <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs">
                      <span className="text-slate-400 font-medium block mb-1">Why PacketSmart AI Recommends:</span>
                      <p className="text-slate-300 leading-relaxed text-[11px]">{item.reason}</p>
                    </div>
                  </div>

                  {/* Alternative Box */}
                  {item.alternative && (
                    <div className="mt-4 p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] flex items-center justify-between">
                      <span className="text-slate-400">Budget Alternative:</span>
                      <span className="font-medium text-cyan-400">{item.alternative}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Product Comparison Matrix Table */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-white font-display">
              Side-by-Side Product Comparison
            </h3>
            <div className="border border-slate-800 rounded-xl overflow-x-auto bg-slate-900/60">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900 text-slate-400 font-medium uppercase text-[10px] tracking-wider">
                    <th className="p-3">Product</th>
                    <th className="p-3">Price</th>
                    <th className="p-3">Budget Status</th>
                    <th className="p-3">Remaining</th>
                    <th className="p-3">Key Specs</th>
                    <th className="p-3">Pros</th>
                    <th className="p-3">Cons</th>
                    <th className="p-3">Recommendation Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-slate-300">
                  {activeResults.recommendations.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/40 transition-colors">
                      <td className="p-3 font-semibold text-white whitespace-nowrap">{item.product_name}</td>
                      <td className="p-3 font-mono font-semibold text-emerald-400 whitespace-nowrap">
                        {formatCurrency(item.estimated_price, currency)}
                      </td>
                      <td className="p-3 whitespace-nowrap">{getStatusBadge(item.budget_status)}</td>
                      <td className="p-3 font-mono tabular-nums whitespace-nowrap">
                        {item.remaining_budget >= 0 ? (
                          <span className="text-emerald-400">+{formatCurrency(item.remaining_budget, currency)}</span>
                        ) : (
                          <span className="text-rose-400">-{formatCurrency(Math.abs(item.remaining_budget), currency)}</span>
                        )}
                      </td>
                      <td className="p-3 max-w-[180px] truncate">{item.features.join(', ')}</td>
                      <td className="p-3 max-w-[150px] text-emerald-300 truncate">{item.pros.join('; ')}</td>
                      <td className="p-3 max-w-[150px] text-rose-300 truncate">{item.cons.join('; ')}</td>
                      <td className="p-3 max-w-[200px] text-slate-400">{item.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
