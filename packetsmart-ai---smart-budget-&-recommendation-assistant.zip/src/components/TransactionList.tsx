import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Trash2, 
  Plus, 
  Receipt, 
  Upload, 
  Check, 
  Sparkles,
  Calendar,
  Store,
  RefreshCw,
  X
} from 'lucide-react';
import { Transaction, BudgetPacket } from '../types/finance';
import { formatCurrency } from '../utils/formatters';
import { DynamicIcon } from './DynamicIcon';

interface TransactionListProps {
  transactions: Transaction[];
  packets: BudgetPacket[];
  currency: string;
  onAddTransaction: (tx: Omit<Transaction, 'id'>) => void;
  onDeleteTransaction: (id: string) => void;
  onOpenNewTransactionModal: () => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  packets,
  currency,
  onAddTransaction,
  onDeleteTransaction,
  onOpenNewTransactionModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPacketFilter, setSelectedPacketFilter] = useState('all');
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);

  // Receipt Scanner State
  const [receiptText, setReceiptText] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scannedResult, setScannedResult] = useState<any | null>(null);

  const filteredTransactions = transactions.filter((tx) => {
    const matchesPacket = selectedPacketFilter === 'all' || tx.packetId === selectedPacketFilter;
    const matchesSearch =
      tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (tx.merchant && tx.merchant.toLowerCase().includes(searchTerm.toLowerCase())) ||
      tx.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesPacket && matchesSearch;
  });

  const getPacket = (packetId: string) => packets.find((p) => p.id === packetId);

  // Handle Receipt AI Scan
  const handleScanReceipt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!receiptText.trim()) return;

    setIsScanning(true);
    setScannedResult(null);

    try {
      const response = await fetch('/api/gemini/parse-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: receiptText,
          availablePackets: packets.map((p) => ({ id: p.id, name: p.name })),
        }),
      });

      const data = await response.json();
      if (data.parsed) {
        setScannedResult(data.parsed);
      }
    } catch (err) {
      console.error('Scan error:', err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleApplyScannedReceipt = () => {
    if (!scannedResult) return;
    onAddTransaction({
      packetId: scannedResult.suggestedPacketId || packets[0].id,
      description: scannedResult.notes || `${scannedResult.merchant} Purchase`,
      amount: scannedResult.total,
      date: scannedResult.date || new Date().toISOString().split('T')[0],
      category: 'Receipt Scan',
      merchant: scannedResult.merchant,
    });
    setIsReceiptModalOpen(false);
    setScannedResult(null);
    setReceiptText('');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      setIsScanning(true);
      setScannedResult(null);

      try {
        const response = await fetch('/api/gemini/parse-receipt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            base64Image: base64Data,
            mimeType: file.type,
            availablePackets: packets.map((p) => ({ id: p.id, name: p.name })),
          }),
        });

        const data = await response.json();
        if (data.parsed) {
          setScannedResult(data.parsed);
        }
      } catch (err) {
        console.error('Receipt image parse error:', err);
      } finally {
        setIsScanning(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-4">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold font-display text-white">
            Transactions & Ledger
          </h2>
          <span className="text-xs text-slate-400">
            {filteredTransactions.length} recorded items
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsReceiptModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 text-slate-200 text-xs font-medium rounded-lg transition-colors cursor-pointer"
          >
            <Receipt className="w-3.5 h-3.5 text-emerald-400" />
            <span>AI Receipt Scanner</span>
          </button>

          <button
            onClick={onOpenNewTransactionModal}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Expense</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        <div className="relative sm:col-span-2">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by merchant, description, or keyword..."
            className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>

        <div>
          <select
            value={selectedPacketFilter}
            onChange={(e) => setSelectedPacketFilter(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 transition-colors"
          >
            <option value="all">All Envelopes</option>
            {packets.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Transactions Table / List */}
      <div className="border border-slate-800 rounded-xl bg-slate-900/60 overflow-hidden">
        <div className="divide-y divide-slate-800/80">
          {filteredTransactions.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No transactions match your current search or filter.
            </div>
          ) : (
            filteredTransactions.map((tx) => {
              const pkt = getPacket(tx.packetId);

              return (
                <div
                  key={tx.id}
                  className="p-3.5 sm:px-4 flex items-center justify-between gap-3 hover:bg-slate-900/90 transition-colors group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300 shrink-0">
                      <DynamicIcon name={pkt?.icon || 'DollarSign'} className="w-4 h-4 text-emerald-400" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-baseline gap-2">
                        <span className="text-xs font-semibold text-white truncate">
                          {tx.description}
                        </span>
                        {tx.isRecurring && (
                          <span className="text-[10px] text-slate-400 font-mono">
                            Recurring
                          </span>
                        )}
                      </div>

                      {/* Clean Unboxed Metadata */}
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span>{tx.date}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate">{pkt?.name || 'Unassigned'}</span>
                        {tx.merchant && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="truncate text-slate-400">{tx.merchant}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-sm font-bold font-mono text-white tabular-nums">
                      -{formatCurrency(tx.amount, currency)}
                    </span>
                    <button
                      onClick={() => onDeleteTransaction(tx.id)}
                      title="Delete entry"
                      className="p-1.5 text-slate-600 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity rounded-md"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* AI Receipt Scanner Modal */}
      {isReceiptModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-lg p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-sm text-white">AI Receipt & Bill Parser</h3>
              </div>
              <button
                onClick={() => setIsReceiptModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Upload a picture or paste receipt text. Gemini extracts the store name, date, total amount, and assigns the correct budget envelope.
            </p>

            {/* Upload or Paste */}
            <div className="space-y-3">
              <label className="block p-4 border border-dashed border-slate-800 hover:border-emerald-500/50 rounded-xl bg-slate-900/30 text-center cursor-pointer transition-colors">
                <Upload className="w-5 h-5 text-slate-400 mx-auto mb-1.5" />
                <span className="text-xs text-slate-300 font-medium block">
                  Upload Receipt Image
                </span>
                <span className="text-[11px] text-slate-500 block">
                  PNG, JPG, or WEBP up to 10MB
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>

              <div className="relative">
                <textarea
                  value={receiptText}
                  onChange={(e) => setReceiptText(e.target.value)}
                  placeholder="Or paste receipt text / SMS transaction notification..."
                  rows={3}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                onClick={handleScanReceipt}
                disabled={isScanning || !receiptText.trim()}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-medium rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                <span>{isScanning ? 'Parsing with Gemini...' : 'Extract & Parse Receipt'}</span>
              </button>
            </div>

            {/* Parsed Result Preview */}
            {scannedResult && (
              <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/30 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white text-sm">
                    {scannedResult.merchant}
                  </span>
                  <span className="font-mono text-emerald-400 font-bold text-sm tabular-nums">
                    {formatCurrency(scannedResult.total, currency)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-slate-400">
                  <div>Date: <strong className="text-slate-200">{scannedResult.date}</strong></div>
                  <div>Tax: <strong className="text-slate-200">${scannedResult.tax || 0}</strong></div>
                </div>

                <div>
                  <span className="text-slate-400 block mb-1">Recommended Envelope:</span>
                  <select
                    value={scannedResult.suggestedPacketId}
                    onChange={(e) =>
                      setScannedResult({ ...scannedResult, suggestedPacketId: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-white"
                  >
                    {packets.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={handleApplyScannedReceipt}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Confirm & Add to Ledger</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
