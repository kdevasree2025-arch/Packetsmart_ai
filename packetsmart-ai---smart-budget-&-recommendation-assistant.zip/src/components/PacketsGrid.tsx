import React, { useState } from 'react';
import { 
  Plus, 
  ArrowRightLeft, 
  Edit3, 
  Trash2, 
  AlertCircle, 
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';
import { BudgetPacket, CategoryType } from '../types/finance';
import { DynamicIcon } from './DynamicIcon';
import { formatCurrency } from '../utils/formatters';

interface PacketsGridProps {
  packets: BudgetPacket[];
  currency: string;
  onOpenNewPacket: () => void;
  onEditPacket: (packet: BudgetPacket) => void;
  onDeletePacket: (packetId: string) => void;
  onQuickExpense: (packetId: string) => void;
  onTransfer: (sourcePacketId: string) => void;
}

export const PacketsGrid: React.FC<PacketsGridProps> = ({
  packets,
  currency,
  onOpenNewPacket,
  onEditPacket,
  onDeletePacket,
  onQuickExpense,
  onTransfer,
}) => {
  const [filter, setFilter] = useState<'all' | CategoryType>('all');

  const filteredPackets = packets.filter((p) => {
    if (filter === 'all') return true;
    return p.categoryType === filter;
  });

  return (
    <div className="space-y-4">
      {/* Header and Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-bold font-display text-white">
            Allocated Budget Packets
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {filteredPackets.length} of {packets.length}
          </span>
        </div>

        {/* Filter Segmented Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filter === 'all'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Packets
          </button>
          <button
            onClick={() => setFilter('needs')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filter === 'needs'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Needs (50%)
          </button>
          <button
            onClick={() => setFilter('wants')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filter === 'wants'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Wants (30%)
          </button>
          <button
            onClick={() => setFilter('savings')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filter === 'savings'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Savings (20%)
          </button>
        </div>
      </div>

      {/* Grid of Packets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPackets.map((packet) => {
          const remaining = packet.budget - packet.spent;
          const percentSpent = packet.budget > 0 ? (packet.spent / packet.budget) * 100 : 0;
          const isOverspent = remaining < 0;
          const isCritical = percentSpent >= 90 && !isOverspent;

          return (
            <div
              key={packet.id}
              className={`p-4 rounded-xl bg-slate-900/60 border transition-all duration-200 flex flex-col justify-between hover:border-slate-700 ${
                isOverspent
                  ? 'border-rose-900/70 bg-rose-950/10'
                  : isCritical
                  ? 'border-amber-900/50'
                  : 'border-slate-800'
              }`}
            >
              {/* Card Header */}
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-200">
                      <DynamicIcon name={packet.icon} className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm text-white tracking-tight leading-snug">
                        {packet.name}
                      </h3>
                      {/* Quiet Unboxed Metadata */}
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                        <span className="capitalize">{packet.categoryType}</span>
                        <span aria-hidden="true">·</span>
                        <span>Envelope</span>
                      </div>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  {isOverspent ? (
                    <div className="flex items-center gap-1 text-[11px] font-medium text-rose-400">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Overspent</span>
                    </div>
                  ) : isCritical ? (
                    <div className="flex items-center gap-1 text-[11px] font-medium text-amber-400">
                      <Clock className="w-3.5 h-3.5" />
                      <span>90%+ Cap</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text-[11px] text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>On Track</span>
                    </div>
                  )}
                </div>

                <p className="text-xs text-slate-400 mt-2.5 line-clamp-1">
                  {packet.description}
                </p>

                {/* Amount Details */}
                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs text-slate-400">Remaining Cushion:</span>
                    <span
                      className={`text-base font-bold font-mono tabular-nums ${
                        isOverspent ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {formatCurrency(remaining, currency)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
                    <span>
                      Spent: <strong className="text-slate-200 font-mono tabular-nums">{formatCurrency(packet.spent, currency)}</strong>
                    </span>
                    <span>
                      Budget: <strong className="text-slate-200 font-mono tabular-nums">{formatCurrency(packet.budget, currency)}</strong>
                    </span>
                  </div>

                  {/* Progress Gauge */}
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2.5">
                    <div
                      className={`h-full transition-all duration-300 rounded-full ${
                        isOverspent
                          ? 'bg-rose-500'
                          : isCritical
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(2, percentSpent))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Toolbar */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-1 text-xs">
                <button
                  onClick={() => onQuickExpense(packet.id)}
                  className="px-2.5 py-1 text-slate-200 hover:text-white bg-slate-800/90 hover:bg-slate-700 rounded-md font-medium transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3 h-3 text-emerald-400" />
                  <span>Log Spend</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onTransfer(packet.id)}
                    title="Transfer money to/from this envelope"
                    className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onEditPacket(packet)}
                    title="Edit envelope cap & settings"
                    className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeletePacket(packet.id)}
                    title="Delete packet envelope"
                    className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {/* Create Packet Quick Action Card */}
        <button
          onClick={onOpenNewPacket}
          className="p-6 rounded-xl border border-dashed border-slate-800 hover:border-emerald-500/50 bg-slate-900/20 hover:bg-slate-900/40 text-slate-400 hover:text-emerald-400 flex flex-col items-center justify-center gap-2 min-h-[200px] transition-all group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-slate-800 group-hover:bg-emerald-950/60 border border-slate-700 group-hover:border-emerald-500/30 flex items-center justify-center transition-colors">
            <Plus className="w-5 h-5 text-slate-300 group-hover:text-emerald-400" />
          </div>
          <span className="font-semibold text-sm text-slate-200 group-hover:text-white">
            Create Custom Packet
          </span>
          <span className="text-xs text-slate-400 text-center max-w-[200px]">
            Add a dedicated envelope for hobbies, travel, or irregular expenses.
          </span>
        </button>
      </div>
    </div>
  );
};
