import React, { useState } from 'react';
import { X, Check, DollarSign } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface IncomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentIncome: number;
  currency: string;
  onSave: (newIncome: number) => void;
}

export const IncomeModal: React.FC<IncomeModalProps> = ({
  isOpen,
  onClose,
  currentIncome,
  currency,
  onSave,
}) => {
  const [incomeStr, setIncomeStr] = useState(String(currentIncome));

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(incomeStr);
    if (!isNaN(val) && val > 0) {
      onSave(val);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-sm text-white">Monthly Take-Home Income</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400">
          Set your total monthly post-tax net income. PacketSmart AI allocates this across your envelopes according to your preferred budgeting strategy.
        </p>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="text-slate-300 block mb-1">Monthly Income</label>
            <div className="relative">
              <input
                type="number"
                step="50"
                min="100"
                value={incomeStr}
                onChange={(e) => setIncomeStr(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono text-base"
                required
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Update Income</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
