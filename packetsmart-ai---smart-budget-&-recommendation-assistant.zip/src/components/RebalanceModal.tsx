import React, { useState } from 'react';
import { X, ArrowRightLeft, Check, Sparkles } from 'lucide-react';
import { BudgetPacket } from '../types/finance';
import { formatCurrency } from '../utils/formatters';

interface RebalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  packets: BudgetPacket[];
  initialSourceId?: string;
  currency: string;
  onConfirmRebalance: (fromPacketId: string, toPacketId: string, amount: number) => void;
}

export const RebalanceModal: React.FC<RebalanceModalProps> = ({
  isOpen,
  onClose,
  packets,
  initialSourceId,
  currency,
  onConfirmRebalance,
}) => {
  const [fromId, setFromId] = useState(initialSourceId || packets[0]?.id || '');
  const [toId, setToId] = useState(packets[1]?.id || packets[0]?.id || '');
  const [amountStr, setAmountStr] = useState('50');

  if (!isOpen) return null;

  const sourcePacket = packets.find((p) => p.id === fromId);
  const destPacket = packets.find((p) => p.id === toId);

  const amount = parseFloat(amountStr) || 0;
  const sourceRemaining = sourcePacket ? sourcePacket.budget - sourcePacket.spent : 0;
  const destRemaining = destPacket ? destPacket.budget - destPacket.spent : 0;

  const handleRebalance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromId || !toId || fromId === toId || amount <= 0) return;
    onConfirmRebalance(fromId, toId, amount);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-sm text-white">Envelope Rebalance / Transfer</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400">
          The core strength of packet budgeting: when one envelope runs low, safely reallocate surplus funds from another envelope without breaking overall monthly savings.
        </p>

        <form onSubmit={handleRebalance} className="space-y-3.5 text-xs">
          {/* Source Envelope */}
          <div>
            <label className="text-slate-300 block mb-1">Transfer From (Surplus Envelope)</label>
            <select
              value={fromId}
              onChange={(e) => setFromId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
            >
              {packets.map((p) => {
                const rem = p.budget - p.spent;
                return (
                  <option key={p.id} value={p.id}>
                    {p.name} ({formatCurrency(rem, currency)} available)
                  </option>
                );
              })}
            </select>
          </div>

          {/* Destination Envelope */}
          <div>
            <label className="text-slate-300 block mb-1">Transfer To (Needing Cushion)</label>
            <select
              value={toId}
              onChange={(e) => setToId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white"
            >
              {packets.map((p) => {
                const rem = p.budget - p.spent;
                return (
                  <option key={p.id} value={p.id} disabled={p.id === fromId}>
                    {p.name} ({formatCurrency(rem, currency)} currently)
                  </option>
                );
              })}
            </select>
          </div>

          {/* Amount */}
          <div>
            <label className="text-slate-300 block mb-1">Amount to Transfer ($)</label>
            <input
              type="number"
              step="1"
              min="1"
              value={amountStr}
              onChange={(e) => setAmountStr(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono"
              required
            />
          </div>

          {/* Live Preview Math */}
          {sourcePacket && destPacket && (
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>{sourcePacket.name} after:</span>
                <span className="font-mono text-slate-200">
                  {formatCurrency(sourceRemaining - amount, currency)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{destPacket.name} after:</span>
                <span className="font-mono text-emerald-400">
                  {formatCurrency(destRemaining + amount, currency)}
                </span>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={fromId === toId || amount <= 0}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Confirm Rebalance</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
