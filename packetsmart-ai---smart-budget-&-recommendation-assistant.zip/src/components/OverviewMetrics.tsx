import React from 'react';
import { 
  TrendingUp, 
  Wallet, 
  PiggyBank, 
  ShieldCheck, 
  ArrowUpRight, 
  Sparkles,
  RefreshCw,
  Scale
} from 'lucide-react';
import { BudgetPacket } from '../types/finance';
import { formatCurrency, calculateHealthScore } from '../utils/formatters';

interface OverviewMetricsProps {
  monthlyIncome: number;
  packets: BudgetPacket[];
  currency: string;
  onOpenRebalanceModal: () => void;
  onOpenPlanGenerator: () => void;
}

export const OverviewMetrics: React.FC<OverviewMetricsProps> = ({
  monthlyIncome,
  packets,
  currency,
  onOpenRebalanceModal,
  onOpenPlanGenerator,
}) => {
  const totalAllocated = packets.reduce((sum, p) => sum + p.budget, 0);
  const totalSpent = packets.reduce((sum, p) => sum + p.spent, 0);
  const remainingInPackets = totalAllocated - totalSpent;
  const unallocatedBuffer = monthlyIncome - totalAllocated;
  
  const health = calculateHealthScore(packets, monthlyIncome);

  // Calculate Needs vs Wants vs Savings percentages
  const needsBudget = packets.filter(p => p.categoryType === 'needs').reduce((s, p) => s + p.budget, 0);
  const wantsBudget = packets.filter(p => p.categoryType === 'wants').reduce((s, p) => s + p.budget, 0);
  const savingsBudget = packets.filter(p => p.categoryType === 'savings').reduce((s, p) => s + p.budget, 0);

  const needsPct = monthlyIncome > 0 ? Math.round((needsBudget / monthlyIncome) * 100) : 0;
  const wantsPct = monthlyIncome > 0 ? Math.round((wantsBudget / monthlyIncome) * 100) : 0;
  const savingsPct = monthlyIncome > 0 ? Math.round((savingsBudget / monthlyIncome) * 100) : 0;

  const totalSpentPercent = totalAllocated > 0 ? Math.min(100, Math.round((totalSpent / totalAllocated) * 100)) : 0;

  return (
    <div className="space-y-4">
      {/* Top Title & Smart Action Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-white tracking-tight">
            Packet Command & Allocation
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Current Period: September 2026</span>
            <span aria-hidden="true">·</span>
            <span>{packets.length} Active Packets</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Based Budget System</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenRebalanceModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
          >
            <Scale className="w-3.5 h-3.5 text-slate-400" />
            <span>Rebalance Packets</span>
          </button>
          <button
            onClick={onOpenPlanGenerator}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-emerald-500/30 rounded-lg shadow-sm transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Generate AI Budget Plan</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* Metric 1: Safe-to-Spend Remaining */}
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Safe-to-Spend In Packets</span>
            <Wallet className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tracking-tight tabular-nums">
              {formatCurrency(remainingInPackets, currency)}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
              <span className="text-slate-300 font-mono tabular-nums">{totalSpentPercent}%</span>
              <span>of allocated envelopes spent</span>
            </div>
          </div>
          {/* Micro Progress Bar */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-3">
            <div 
              className={`h-full transition-all duration-500 ${
                totalSpentPercent > 90 ? 'bg-rose-500' : totalSpentPercent > 75 ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${totalSpentPercent}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Total Spent / Allocated */}
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Total Spent This Month</span>
            <TrendingUp className="w-4 h-4 text-sky-400" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tracking-tight tabular-nums">
              {formatCurrency(totalSpent, currency)}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
              <span>Cap:</span>
              <span className="text-slate-200 font-mono tabular-nums">{formatCurrency(totalAllocated, currency)}</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-500 mt-3 flex items-center justify-between">
            <span>Buffer pool unallocated:</span>
            <span className="font-mono text-emerald-400 font-medium tabular-nums">{formatCurrency(unallocatedBuffer, currency)}</span>
          </div>
        </div>

        {/* Metric 3: Savings Velocity */}
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Savings & Growth Rate</span>
            <PiggyBank className="w-4 h-4 text-teal-400" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tracking-tight tabular-nums">
              {health.details.savingsRatePercentage}%
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
              <span className="text-emerald-400 font-medium">{formatCurrency(savingsBudget, currency)}</span>
              <span>dedicated to savings</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 mt-3 flex items-center gap-1.5">
            <span className="text-slate-300 font-medium">50/30/20 target:</span>
            <span>Needs {needsPct}% · Wants {wantsPct}%</span>
          </div>
        </div>

        {/* Metric 4: Packet Health Score */}
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Packet Health Score</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-bold font-mono text-white tracking-tight tabular-nums">
                {health.score}
              </span>
              <span className="text-xs font-mono text-slate-500">/ 100</span>
              <span className="ml-auto text-xs font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                {health.grade}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-2 line-clamp-1">
              {health.details.summary}
            </p>
          </div>
          <div className="text-[11px] text-slate-400 mt-3 flex items-center justify-between">
            <span>Overspent envelopes:</span>
            <span className={`font-mono font-medium ${health.details.overspentPacketsCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {health.details.overspentPacketsCount}
            </span>
          </div>
        </div>

      </div>
    </div>
  );
};
