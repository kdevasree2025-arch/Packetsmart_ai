import { BudgetPacket } from '../types/finance';

export const CURRENCY_SYMBOLS: Record<string, string> = {
  USD: '$',
  EUR: '€',
  GBP: '£',
  INR: '₹',
  JPY: '¥',
  CAD: 'CA$',
  AUD: 'AU$',
};

export function formatCurrency(amount: number, currency: string = 'USD'): string {
  const symbol = CURRENCY_SYMBOLS[currency] || '$';
  return `${symbol}${amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatCompactCurrency(amount: number, currency: string = 'USD'): string {
  const symbol = CURRENCY_SYMBOLS[currency] || '$';
  if (Math.abs(amount) >= 1000) {
    return `${symbol}${(amount / 1000).toFixed(1)}k`;
  }
  return `${symbol}${Math.round(amount)}`;
}

export interface HealthScoreResult {
  score: number;
  grade: 'Excellent' | 'Healthy' | 'Caution' | 'Action Needed';
  details: {
    overspentPacketsCount: number;
    savingsRatePercentage: number;
    cushionPercentage: number;
    summary: string;
  };
}

export function calculateHealthScore(
  packets: BudgetPacket[],
  monthlyIncome: number
): HealthScoreResult {
  if (!packets.length || monthlyIncome <= 0) {
    return {
      score: 70,
      grade: 'Healthy',
      details: {
        overspentPacketsCount: 0,
        savingsRatePercentage: 20,
        cushionPercentage: 10,
        summary: 'Baseline score based on initialized envelopes.',
      },
    };
  }

  let totalAllocated = 0;
  let totalSpent = 0;
  let overspentCount = 0;
  let savingsAllocated = 0;

  for (const pkt of packets) {
    totalAllocated += pkt.budget;
    totalSpent += pkt.spent;
    if (pkt.spent > pkt.budget) {
      overspentCount++;
    }
    if (pkt.categoryType === 'savings') {
      savingsAllocated += pkt.spent;
    }
  }

  const savingsRate = Math.round((savingsAllocated / monthlyIncome) * 100);
  const remainingTotal = monthlyIncome - totalSpent;
  const cushionPct = Math.round((remainingTotal / monthlyIncome) * 100);

  // Scoring engine:
  // Base 100
  // Deduct 15 for each overspent packet
  // Reward for savings rate (up to +20 points)
  // Deduct if total spent > monthlyIncome
  let calculatedScore = 100;

  calculatedScore -= overspentCount * 14;

  if (totalSpent > monthlyIncome) {
    const deficitRatio = (totalSpent - monthlyIncome) / monthlyIncome;
    calculatedScore -= Math.round(deficitRatio * 50);
  }

  if (savingsRate < 10) {
    calculatedScore -= 12;
  } else if (savingsRate >= 20) {
    calculatedScore += 5;
  }

  const finalScore = Math.max(15, Math.min(99, calculatedScore));

  let grade: HealthScoreResult['grade'] = 'Excellent';
  let summary = 'Outstanding discipline. Your packet buffers are well-shielded.';

  if (finalScore < 60) {
    grade = 'Action Needed';
    summary = `${overspentCount} packet(s) breached limits. Urgent rebalance recommended.`;
  } else if (finalScore < 75) {
    grade = 'Caution';
    summary = 'Spending is tight in 1-2 envelopes. Review dining or discretionary packets.';
  } else if (finalScore < 88) {
    grade = 'Healthy';
    summary = 'Solid packet tracking with active savings allocation.';
  }

  return {
    score: finalScore,
    grade,
    details: {
      overspentPacketsCount: overspentCount,
      savingsRatePercentage: savingsRate,
      cushionPercentage: cushionPct,
      summary,
    },
  };
}
