import React, { useState, useEffect } from 'react';
import { 
  DEFAULT_PACKETS, 
  DEFAULT_TRANSACTIONS, 
  DEFAULT_GOALS, 
  DEFAULT_RECOMMENDATIONS 
} from './data/defaultData';
import { BudgetPacket, Transaction, SavingsGoal, Recommendation } from './types/finance';
import { Navbar } from './components/Navbar';
import { OverviewMetrics } from './components/OverviewMetrics';
import { PacketsGrid } from './components/PacketsGrid';
import { SmartRecommendations } from './components/SmartRecommendations';
import { AffordabilityChecker } from './components/AffordabilityChecker';
import { TransactionList } from './components/TransactionList';
import { SavingsGoals } from './components/SavingsGoals';
import { AiAdvisorChat } from './components/AiAdvisorChat';
import { ProductRecommendationFinder } from './components/ProductRecommendationFinder';
import { RebalanceModal } from './components/RebalanceModal';
import { PacketModal } from './components/PacketModal';
import { TransactionModal } from './components/TransactionModal';
import { IncomeModal } from './components/IncomeModal';
import { PlanGeneratorModal } from './components/PlanGeneratorModal';

export default function App() {
  // Local storage state initialization
  const [monthlyIncome, setMonthlyIncome] = useState<number>(() => {
    const saved = localStorage.getItem('packetsmart_income');
    return saved ? parseFloat(saved) : 4850;
  });

  const [currency, setCurrency] = useState<string>(() => {
    return localStorage.getItem('packetsmart_currency') || 'USD';
  });

  const [packets, setPackets] = useState<BudgetPacket[]>(() => {
    const saved = localStorage.getItem('packetsmart_packets');
    return saved ? JSON.parse(saved) : DEFAULT_PACKETS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('packetsmart_transactions');
    return saved ? JSON.parse(saved) : DEFAULT_TRANSACTIONS;
  });

  const [goals, setGoals] = useState<SavingsGoal[]>(() => {
    const saved = localStorage.getItem('packetsmart_goals');
    return saved ? JSON.parse(saved) : DEFAULT_GOALS;
  });

  const [recommendations, setRecommendations] = useState<Recommendation[]>(() => {
    const saved = localStorage.getItem('packetsmart_recs');
    return saved ? JSON.parse(saved) : DEFAULT_RECOMMENDATIONS;
  });

  const [activeView, setActiveView] = useState<
    'products' | 'dashboard' | 'affordability' | 'recommendations' | 'transactions' | 'goals'
  >('products');

  const [isAiAdvisorOpen, setIsAiAdvisorOpen] = useState(false);
  const [isLoadingRecs, setIsLoadingRecs] = useState(false);

  // Modals state
  const [isPacketModalOpen, setIsPacketModalOpen] = useState(false);
  const [packetToEdit, setPacketToEdit] = useState<BudgetPacket | null>(null);

  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [initialTxPacketId, setInitialTxPacketId] = useState<string | undefined>();

  const [isRebalanceModalOpen, setIsRebalanceModalOpen] = useState(false);
  const [initialRebalanceSourceId, setInitialRebalanceSourceId] = useState<string | undefined>();

  const [isIncomeModalOpen, setIsIncomeModalOpen] = useState(false);
  const [isPlanGeneratorOpen, setIsPlanGeneratorOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('packetsmart_income', String(monthlyIncome));
  }, [monthlyIncome]);

  useEffect(() => {
    localStorage.setItem('packetsmart_currency', currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem('packetsmart_packets', JSON.stringify(packets));
  }, [packets]);

  useEffect(() => {
    localStorage.setItem('packetsmart_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('packetsmart_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('packetsmart_recs', JSON.stringify(recommendations));
  }, [recommendations]);

  // Recalculate packet spent when transactions change
  const handleAddTransaction = (newTx: Omit<Transaction, 'id'>) => {
    const id = `tx-${Date.now()}`;
    const transaction: Transaction = { ...newTx, id };
    setTransactions((prev) => [transaction, ...prev]);

    // Update target packet spent
    setPackets((prev) =>
      prev.map((pkt) => {
        if (pkt.id === newTx.packetId) {
          return { ...pkt, spent: pkt.spent + newTx.amount };
        }
        return pkt;
      })
    );
  };

  const handleDeleteTransaction = (id: string) => {
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;

    setTransactions((prev) => prev.filter((t) => t.id !== id));

    // Deduct from packet spent
    setPackets((prev) =>
      prev.map((pkt) => {
        if (pkt.id === tx.packetId) {
          return { ...pkt, spent: Math.max(0, pkt.spent - tx.amount) };
        }
        return pkt;
      })
    );
  };

  // Rebalance envelope funds
  const handleRebalance = (fromId: string, toId: string, amount: number) => {
    setPackets((prev) =>
      prev.map((p) => {
        if (p.id === fromId) {
          return { ...p, budget: Math.max(0, p.budget - amount) };
        }
        if (p.id === toId) {
          return { ...p, budget: p.budget + amount };
        }
        return p;
      })
    );
  };

  // Save new or edited packet
  const handleSavePacket = (packetData: Omit<BudgetPacket, 'id' | 'spent'> & { id?: string }) => {
    if (packetData.id) {
      // Edit existing
      setPackets((prev) =>
        prev.map((p) => (p.id === packetData.id ? { ...p, ...packetData } : p))
      );
    } else {
      // Create new
      const newPacket: BudgetPacket = {
        ...packetData,
        id: `pkt-${Date.now()}`,
        spent: 0,
      };
      setPackets((prev) => [...prev, newPacket]);
    }
  };

  const handleDeletePacket = (packetId: string) => {
    setPackets((prev) => prev.filter((p) => p.id !== packetId));
  };

  // Savings goals
  const handleAddGoal = (newGoal: Omit<SavingsGoal, 'id'>) => {
    const id = `goal-${Date.now()}`;
    setGoals((prev) => [...prev, { ...newGoal, id }]);
  };

  const handleDepositToGoal = (goalId: string, amount: number, sourcePacketId?: string) => {
    setGoals((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, currentAmount: g.currentAmount + amount } : g))
    );

    // If a source envelope was chosen, log it
    if (sourcePacketId) {
      handleAddTransaction({
        packetId: sourcePacketId,
        description: `Deposit to Goal`,
        amount,
        date: new Date().toISOString().split('T')[0],
        category: 'Savings Deposit',
      });
    }
  };

  const handleDeleteGoal = (goalId: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== goalId));
  };

  // AI Recommendations
  const handleRefreshRecommendations = async () => {
    setIsLoadingRecs(true);
    try {
      const response = await fetch('/api/gemini/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          packets,
          transactions,
          monthlyIncome,
          savingsGoal: 1200,
        }),
      });

      const data = await response.json();
      if (data.recommendations && Array.isArray(data.recommendations)) {
        setRecommendations(data.recommendations);
      }
    } catch (err) {
      console.error('Failed to refresh recommendations:', err);
    } finally {
      setIsLoadingRecs(false);
    }
  };

  const handleApplyRecommendation = (rec: Recommendation) => {
    if (rec.type === 'rebalance') {
      // Apply $30-$50 rebalance if suitable
      const surplusPkt = packets.find((p) => p.budget - p.spent > 100);
      const deficitPkt = packets.find((p) => p.spent > p.budget * 0.85);

      if (surplusPkt && deficitPkt && surplusPkt.id !== deficitPkt.id) {
        handleRebalance(surplusPkt.id, deficitPkt.id, 40);
      }
    }

    setRecommendations((prev) =>
      prev.map((r) => (r.id === rec.id ? { ...r, applied: true } : r))
    );
  };

  // Reset to sample data
  const handleResetData = () => {
    if (window.confirm('Reset PacketSmart AI to initial sample envelopes and transactions?')) {
      setMonthlyIncome(4850);
      setCurrency('USD');
      setPackets(DEFAULT_PACKETS);
      setTransactions(DEFAULT_TRANSACTIONS);
      setGoals(DEFAULT_GOALS);
      setRecommendations(DEFAULT_RECOMMENDATIONS);
      localStorage.clear();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        currency={currency}
        onCurrencyChange={setCurrency}
        monthlyIncome={monthlyIncome}
        onEditIncome={() => setIsIncomeModalOpen(true)}
        onOpenNewPacket={() => {
          setPacketToEdit(null);
          setIsPacketModalOpen(true);
        }}
        onOpenNewTransaction={() => {
          setInitialTxPacketId(undefined);
          setIsTransactionModalOpen(true);
        }}
        onOpenPlanGenerator={() => setIsPlanGeneratorOpen(true)}
        onToggleAiAdvisor={() => setIsAiAdvisorOpen(!isAiAdvisorOpen)}
        isAiAdvisorOpen={isAiAdvisorOpen}
        onResetData={handleResetData}
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Dynamic Views */}
        {activeView === 'products' && (
          <ProductRecommendationFinder currency={currency} />
        )}

        {activeView === 'dashboard' && (
          <div className="space-y-6">
            {/* KPI Health Overview */}
            <OverviewMetrics
              monthlyIncome={monthlyIncome}
              packets={packets}
              currency={currency}
              onOpenRebalanceModal={() => {
                setInitialRebalanceSourceId(undefined);
                setIsRebalanceModalOpen(true);
              }}
              onOpenPlanGenerator={() => setIsPlanGeneratorOpen(true)}
            />

            {/* Envelopes Grid */}
            <PacketsGrid
              packets={packets}
              currency={currency}
              onOpenNewPacket={() => {
                setPacketToEdit(null);
                setIsPacketModalOpen(true);
              }}
              onEditPacket={(pkt) => {
                setPacketToEdit(pkt);
                setIsPacketModalOpen(true);
              }}
              onDeletePacket={handleDeletePacket}
              onQuickExpense={(pktId) => {
                setInitialTxPacketId(pktId);
                setIsTransactionModalOpen(true);
              }}
              onTransfer={(pktId) => {
                setInitialRebalanceSourceId(pktId);
                setIsRebalanceModalOpen(true);
              }}
            />

            {/* Quick Preview of Smart Recommendations */}
            <div className="pt-2">
              <SmartRecommendations
                recommendations={recommendations.slice(0, 2)}
                onRefreshRecommendations={handleRefreshRecommendations}
                isLoading={isLoadingRecs}
                onApplyRecommendation={handleApplyRecommendation}
                currency={currency}
              />
            </div>
          </div>
        )}

        {activeView === 'recommendations' && (
          <SmartRecommendations
            recommendations={recommendations}
            onRefreshRecommendations={handleRefreshRecommendations}
            isLoading={isLoadingRecs}
            onApplyRecommendation={handleApplyRecommendation}
            currency={currency}
          />
        )}

        {activeView === 'affordability' && (
          <AffordabilityChecker
            packets={packets}
            currency={currency}
            monthlyIncome={monthlyIncome}
            onLogPurchase={(packetId, description, amount) => {
              handleAddTransaction({
                packetId,
                description,
                amount,
                date: new Date().toISOString().split('T')[0],
                category: 'Discretionary',
              });
            }}
          />
        )}

        {activeView === 'transactions' && (
          <TransactionList
            transactions={transactions}
            packets={packets}
            currency={currency}
            onAddTransaction={handleAddTransaction}
            onDeleteTransaction={handleDeleteTransaction}
            onOpenNewTransactionModal={() => {
              setInitialTxPacketId(undefined);
              setIsTransactionModalOpen(true);
            }}
          />
        )}

        {activeView === 'goals' && (
          <SavingsGoals
            goals={goals}
            packets={packets}
            currency={currency}
            onAddGoal={handleAddGoal}
            onDepositToGoal={handleDepositToGoal}
            onDeleteGoal={handleDeleteGoal}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>PacketSmart AI — Your smart budget and recommendation assistant</span>
          <div className="flex items-center gap-3">
            <span>Powered by Gemini 3.8</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Based Envelope Accounting</span>
          </div>
        </div>
      </footer>

      {/* AI Advisor Chat Slide-over */}
      <AiAdvisorChat
        isOpen={isAiAdvisorOpen}
        onClose={() => setIsAiAdvisorOpen(false)}
        monthlyIncome={monthlyIncome}
        packets={packets}
        transactions={transactions}
        goals={goals}
        currency={currency}
      />

      {/* Modals */}
      <RebalanceModal
        isOpen={isRebalanceModalOpen}
        onClose={() => setIsRebalanceModalOpen(false)}
        packets={packets}
        initialSourceId={initialRebalanceSourceId}
        currency={currency}
        onConfirmRebalance={handleRebalance}
      />

      <PacketModal
        isOpen={isPacketModalOpen}
        onClose={() => setIsPacketModalOpen(false)}
        packetToEdit={packetToEdit}
        onSave={handleSavePacket}
      />

      <TransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        packets={packets}
        initialPacketId={initialTxPacketId}
        currency={currency}
        onSave={handleAddTransaction}
      />

      <IncomeModal
        isOpen={isIncomeModalOpen}
        onClose={() => setIsIncomeModalOpen(false)}
        currentIncome={monthlyIncome}
        currency={currency}
        onSave={setMonthlyIncome}
      />

      <PlanGeneratorModal
        isOpen={isPlanGeneratorOpen}
        onClose={() => setIsPlanGeneratorOpen(false)}
        monthlyIncome={monthlyIncome}
        currency={currency}
        onAdoptPlan={(newPlan) => setPackets(newPlan)}
      />
    </div>
  );
}
