export type CategoryType = 'needs' | 'wants' | 'savings';

export interface BudgetPacket {
  id: string;
  name: string;
  budget: number;
  spent: number;
  icon: string;
  color: 'emerald' | 'sky' | 'indigo' | 'amber' | 'rose' | 'purple' | 'teal' | 'orange';
  categoryType: CategoryType;
  description: string;
  rolloverEnabled?: boolean;
}

export interface Transaction {
  id: string;
  packetId: string;
  description: string;
  amount: number;
  date: string;
  category: string;
  merchant?: string;
  notes?: string;
  isRecurring?: boolean;
}

export interface Recommendation {
  id: string;
  title: string;
  description: string;
  type: 'rebalance' | 'leak_detected' | 'saving_hack' | 'milestone';
  priority: 'high' | 'medium' | 'low';
  potentialMonthlySavings: number;
  packetName?: string | null;
  suggestedAction: string;
  canAutoApply: boolean;
  applied?: boolean;
}

export interface AffordabilityDecision {
  verdict: 'YES_AFFORDABLE' | 'YES_WITH_REBALANCE' | 'DELAY_RECOMMENDED' | 'NOT_RECOMMENDED';
  verdictTitle: string;
  explanation: string;
  impactScore: number;
  packetAftermath: number;
  smartStrategy: string;
  alternativeTip?: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  packetId?: string;
  icon: string;
}

export interface UserFinancialProfile {
  monthlyIncome: number;
  currency: string;
  month: string;
}
