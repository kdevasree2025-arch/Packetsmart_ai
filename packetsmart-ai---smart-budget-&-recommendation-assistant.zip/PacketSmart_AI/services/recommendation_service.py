import os
import json
from .ai_service import AIService
from database.database import db
from database.models import RecommendationSearch

class RecommendationService:
    """
    Core business logic engine for PacketSmart AI.
    Handles validation, AI invocation, fallback product matching, budget math, and DB persistence.
    """

    def __init__(self, ai_service=None):
        self.ai_service = ai_service or AIService()
        self.sample_data_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 'data', 'sample_products.json'
        )

    def validate_inputs(self, budget, category, requirements):
        """Validates incoming recommendation request fields."""
        errors = []

        if budget is None or budget == '':
            errors.append("Budget is required.")
        else:
            try:
                budget_float = float(budget)
                if budget_float <= 0:
                    errors.append("Budget must be a positive number greater than zero.")
            except (ValueError, TypeError):
                errors.append("Budget must be a valid numerical value.")

        if not category or not str(category).strip():
            errors.append("Product category is required.")

        if not requirements or not str(requirements).strip():
            errors.append("Requirements or preferences description is required.")

        return errors

    def get_recommendations(self, budget, category, requirements, brand_preference=None, save_history=True):
        """
        Coordinates AI generation or intelligent fallback, performs budget calculations,
        and saves search record to the database.
        """
        budget_float = float(budget)
        cleaned_category = str(category).strip()
        cleaned_requirements = str(requirements).strip()
        cleaned_brand = str(brand_preference).strip() if brand_preference else None

        used_fallback = False
        fallback_notice = None

        # 1. Attempt AI Recommendation
        if self.ai_service.is_configured():
            try:
                ai_data = self.ai_service.generate_recommendations(
                    budget=budget_float,
                    category=cleaned_category,
                    requirements=cleaned_requirements,
                    brand_preference=cleaned_brand
                )
                recommendations = ai_data.get('recommendations', [])
                if not recommendations:
                    raise ValueError("AI returned empty recommendations list.")
            except Exception as e:
                # Log error and trigger graceful fallback
                used_fallback = True
                fallback_notice = f"AI service temporarily unavailable ({str(e)}). Displaying verified curated alternatives from catalog."
                recommendations = self._generate_fallback_recommendations(
                    budget_float, cleaned_category, cleaned_requirements, cleaned_brand
                )
        else:
            used_fallback = True
            fallback_notice = "AI API key not configured. Displaying smart matched recommendations from curated product catalog."
            recommendations = self._generate_fallback_recommendations(
                budget_float, cleaned_category, cleaned_requirements, cleaned_brand
            )

        # 2. Enrich recommendations with precise budget arithmetic
        enriched_recommendations = []
        for item in recommendations:
            enriched = self._enrich_item_with_budget_logic(item, budget_float)
            enriched_recommendations.append(enriched)

        result_payload = {
            "budget": budget_float,
            "category": cleaned_category,
            "requirements": cleaned_requirements,
            "brand_preference": cleaned_brand,
            "used_fallback": used_fallback,
            "fallback_notice": fallback_notice,
            "recommendations": enriched_recommendations
        }

        # 3. Save to database history
        search_record_id = None
        if save_history:
            try:
                record = RecommendationSearch(
                    budget=budget_float,
                    category=cleaned_category,
                    requirements=cleaned_requirements,
                    brand_preference=cleaned_brand
                )
                record.set_recommendations(result_payload)
                db.session.add(record)
                db.session.commit()
                search_record_id = record.id
                result_payload["search_id"] = search_record_id
            except Exception as db_err:
                db.session.rollback()
                result_payload["db_warning"] = f"Unable to save search to history: {str(db_err)}"

        return result_payload

    def _enrich_item_with_budget_logic(self, item, user_budget):
        """Calculates remaining_budget and enforces strict budget classification."""
        try:
            price = float(item.get('estimated_price', 0))
        except (ValueError, TypeError):
            price = 0.0

        remaining_budget = round(user_budget - price, 2)

        # Strict budget classification
        if price <= user_budget:
            status = "Within Budget"
        elif price <= (user_budget * 1.15):
            status = "Slightly Above Budget"
        else:
            status = "Over Budget"

        return {
            "product_name": item.get('product_name', 'Unnamed Product'),
            "estimated_price": price,
            "budget_status": status,
            "remaining_budget": remaining_budget,
            "features": item.get('features', []),
            "pros": item.get('pros', []),
            "cons": item.get('cons', []),
            "reason": item.get('reason', 'Matches your desired category and specifications.'),
            "alternative": item.get('alternative', 'Standard alternative option available in catalog.')
        }

    def _generate_fallback_recommendations(self, budget, category, requirements, brand_preference):
        """Loads sample products and applies heuristic matching when AI is unavailable."""
        all_products = []
        if os.path.exists(self.sample_data_path):
            try:
                with open(self.sample_data_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    all_products = data.get('products', [])
            except Exception:
                all_products = []

        # Filter by category
        matched_category = [p for p in all_products if p.get('category', '').lower() == category.lower()]
        if not matched_category:
            matched_category = all_products

        # Filter or sort by brand preference if provided
        if brand_preference:
            brand_matches = [p for p in matched_category if brand_preference.lower() in p.get('brand', '').lower()]
            if brand_matches:
                matched_category = brand_matches + [p for p in matched_category if p not in brand_matches]

        # Sort products by closeness to budget
        matched_category.sort(key=lambda p: abs(p.get('estimated_price', 0) - budget))
        selected = matched_category[:3]

        recommendations = []
        for p in selected:
            price = float(p.get('estimated_price', 0))
            recommendations.append({
                "product_name": p.get('product_name'),
                "estimated_price": price,
                "features": p.get('features', []),
                "pros": p.get('pros', []),
                "cons": p.get('cons', []),
                "reason": f"Top-rated {category} matching your budget requirements and essential performance criteria.",
                "alternative": p.get('alternative', 'Budget-friendly alternative')
            })

        return recommendations
