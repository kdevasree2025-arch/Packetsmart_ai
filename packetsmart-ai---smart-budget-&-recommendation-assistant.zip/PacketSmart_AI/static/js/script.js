/**
 * PacketSmart AI - Client-side Interaction Script
 */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('recommendation-form');
  const loadingOverlay = document.getElementById('loading-overlay');
  const errorBanner = document.getElementById('form-error-banner');
  const submitBtn = document.getElementById('submit-btn');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Reset errors
      hideError();

      const budgetVal = document.getElementById('budget').value;
      const categoryVal = document.getElementById('category').value;
      const requirementsVal = document.getElementById('requirements').value;
      const brandVal = document.getElementById('brand_preference').value;

      // Basic client-side checks
      const budgetNum = parseFloat(budgetVal);
      if (isNaN(budgetNum) || budgetNum <= 0) {
        showError('Please enter a valid budget greater than $0.');
        return;
      }

      if (!categoryVal) {
        showError('Please choose a product category.');
        return;
      }

      if (!requirementsVal.trim()) {
        showError('Please specify your requirements or use-case.');
        return;
      }

      // Show loading UI
      showLoading(true);

      try {
        const response = await fetch('/api/recommend', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            budget: budgetNum,
            category: categoryVal,
            requirements: requirementsVal.trim(),
            brand_preference: brandVal ? brandVal.trim() : null
          })
        });

        const result = await response.json();

        if (response.ok && result.success) {
          const searchId = result.data.search_id;
          // Redirect to the rich recommendations view
          window.location.href = `/recommendations?search_id=${searchId}`;
        } else {
          showLoading(false);
          const errorMsg = result.errors 
            ? result.errors.join(' ') 
            : (result.error || 'Failed to generate recommendations. Please try again.');
          showError(errorMsg);
        }
      } catch (err) {
        showLoading(false);
        showError('Network error connecting to PacketSmart AI service. Please check your connection.');
      }
    });
  }

  function showLoading(isLoading) {
    if (loadingOverlay) {
      if (isLoading) {
        loadingOverlay.classList.remove('hidden');
      } else {
        loadingOverlay.classList.add('hidden');
      }
    }
    if (submitBtn) {
      submitBtn.disabled = isLoading;
    }
  }

  function showError(message) {
    if (errorBanner) {
      errorBanner.textContent = message;
      errorBanner.classList.remove('hidden');
      errorBanner.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function hideError() {
    if (errorBanner) {
      errorBanner.textContent = '';
      errorBanner.classList.add('hidden');
    }
  }
});
