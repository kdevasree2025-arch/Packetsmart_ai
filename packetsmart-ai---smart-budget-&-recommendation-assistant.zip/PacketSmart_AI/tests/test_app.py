import pytest
import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from config import TestingConfig
from database.database import db

@pytest.fixture
def app():
    """Create test application configured with in-memory SQLite database."""
    app = create_app(TestingConfig)
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.fixture
def client(app):
    return app.test_client()

def test_homepage_loads(client):
    """Verify that homepage renders with HTTP 200 and core brand elements."""
    response = client.get('/')
    assert response.status_code == 200
    assert b"PacketSmart" in response.data
    assert b"Available Budget" in response.data

def test_recommend_api_validation_failure(client):
    """Verify that missing budget or category returns HTTP 422 with structured error list."""
    payload = {
        "budget": -50,
        "category": "",
        "requirements": ""
    }
    response = client.post('/api/recommend', json=payload)
    assert response.status_code == 422
    data = response.get_json()
    assert data["success"] is False
    assert len(data["errors"]) >= 2

def test_recommend_api_success_with_fallback(client):
    """Verify that valid recommendation request completes successfully via fallback catalog."""
    payload = {
        "budget": 450,
        "category": "Smartphones",
        "requirements": "Good battery life and camera",
        "brand_preference": "Samsung"
    }
    response = client.post('/api/recommend', json=payload)
    assert response.status_code == 200
    data = response.get_json()
    assert data["success"] is True
    assert "recommendations" in data["data"]
    assert len(data["data"]["recommendations"]) > 0

def test_history_api(client):
    """Verify that history endpoint tracks created recommendations and allows deletion."""
    # 1. Create a recommendation search
    payload = {
        "budget": 300,
        "category": "Headphones",
        "requirements": "Noise canceling for travel"
    }
    create_res = client.post('/api/recommend', json=payload)
    search_id = create_res.get_json()["data"]["search_id"]

    # 2. Query history
    history_res = client.get('/api/history')
    assert history_res.status_code == 200
    history_data = history_res.get_json()
    assert history_data["count"] >= 1

    # 3. Query item by ID
    item_res = client.get(f'/api/history/{search_id}')
    assert item_res.status_code == 200
    assert item_res.get_json()["search"]["id"] == search_id

    # 4. Delete item
    del_res = client.delete(f'/api/history/{search_id}')
    assert del_res.status_code == 200
    assert del_res.get_json()["success"] is True
