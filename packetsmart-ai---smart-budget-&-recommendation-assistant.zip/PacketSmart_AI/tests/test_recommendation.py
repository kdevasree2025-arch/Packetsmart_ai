import pytest
import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from services.recommendation_service import RecommendationService
from services.ai_service import AIService

class MockFailingAIService(AIService):
    """Simulates AI API failure to test fallback behavior."""
    def is_configured(self):
        return True

    def generate_recommendations(self, *args, **kwargs):
        raise ConnectionError("Simulated LLM Gateway Timeout 504")

def test_validation_logic():
    """Verify input validation rules."""
    service = RecommendationService()

    # Empty inputs
    errors = service.validate_inputs(None, "", "")
    assert len(errors) == 3

    # Negative budget
    errors = service.validate_inputs(-10, "Laptops", "Work")
    assert any("positive number" in e for e in errors)

    # Valid inputs
    errors = service.validate_inputs(800, "Laptops", "Programming and light gaming")
    assert len(errors) == 0

def test_budget_classification_logic():
    """Verify within budget, slightly above, and over budget calculations."""
    service = RecommendationService()

    user_budget = 500.0

    # 1. Within budget
    item_within = service._enrich_item_with_budget_logic({"estimated_price": 450.0}, user_budget)
    assert item_within["budget_status"] == "Within Budget"
    assert item_within["remaining_budget"] == 50.0

    # 2. Slightly above budget (<= 15% over)
    item_slightly = service._enrich_item_with_budget_logic({"estimated_price": 540.0}, user_budget)
    assert item_slightly["budget_status"] == "Slightly Above Budget"
    assert item_slightly["remaining_budget"] == -40.0

    # 3. Over budget (> 15% over)
    item_over = service._enrich_item_with_budget_logic({"estimated_price": 750.0}, user_budget)
    assert item_over["budget_status"] == "Over Budget"
    assert item_over["remaining_budget"] == -250.0

def test_ai_fallback_resilience():
    """Verify that when AI service fails, the service falls back gracefully without crashing."""
    failing_ai = MockFailingAIService()
    service = RecommendationService(ai_service=failing_ai)

    result = service.get_recommendations(
        budget=400,
        category="Smartphones",
        requirements="Good battery life",
        save_history=False
    )

    assert result["used_fallback"] is True
    assert result["fallback_notice"] is not None
    assert len(result["recommendations"]) > 0
    assert result["recommendations"][0]["product_name"] is not None
