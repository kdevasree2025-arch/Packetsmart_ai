from flask import Blueprint, render_template, request, redirect, url_for
from services.recommendation_service import RecommendationService
from database.models import RecommendationSearch

main_bp = Blueprint('main', __name__)
rec_service = RecommendationService()

@main_bp.route('/', methods=['GET'])
def index():
    """Renders the main PacketSmart AI homepage."""
    categories = [
        "Smartphones",
        "Laptops",
        "Headphones",
        "Smart Watches",
        "Cameras",
        "Tablets",
        "Gaming Accessories",
        "Other"
    ]
    return render_template('index.html', categories=categories)

@main_bp.route('/recommendations', methods=['GET'])
def view_recommendations():
    """Renders the recommendations page or redirects home if no search id."""
    search_id = request.args.get('search_id')
    if not search_id:
        return redirect(url_for('main.index'))

    search_record = RecommendationSearch.query.get(search_id)
    if not search_record:
        return render_template('error.html', message="Recommendation search not found."), 404

    data = search_record.get_recommendations()
    return render_template('recommendations.html', result=data, search_id=search_id)

@main_bp.route('/history', methods=['GET'])
def history_page():
    """Renders the recommendation history page."""
    searches = RecommendationSearch.query.order_by(RecommendationSearch.created_at.desc()).all()
    history_items = [s.to_dict() for s in searches]
    return render_template('history.html', history=history_items)

@main_bp.app_errorhandler(404)
def not_found_error(error):
    return render_template('error.html', message="The requested page does not exist.", status_code=404), 404

@main_bp.app_errorhandler(500)
def internal_error(error):
    return render_template('error.html', message="An unexpected server error occurred.", status_code=500), 500
