from flask import Blueprint, request, jsonify
from services.recommendation_service import RecommendationService
from database.database import db
from database.models import RecommendationSearch

api_bp = Blueprint('api', __name__, url_prefix='/api')
rec_service = RecommendationService()

@api_bp.route('/recommend', methods=['POST'])
def recommend():
    """
    POST /api/recommend
    Accepts JSON payload: { budget, category, requirements, brand_preference }
    Returns structured recommendations and stores search history.
    """
    if not request.is_json:
        return jsonify({"success": False, "errors": ["Request must be application/json"]}), 400

    data = request.get_json()
    budget = data.get('budget')
    category = data.get('category')
    requirements = data.get('requirements')
    brand_preference = data.get('brand_preference')

    errors = rec_service.validate_inputs(budget, category, requirements)
    if errors:
        return jsonify({"success": False, "errors": errors}), 422

    try:
        result = rec_service.get_recommendations(
            budget=budget,
            category=category,
            requirements=requirements,
            brand_preference=brand_preference,
            save_history=True
        )
        return jsonify({"success": True, "data": result}), 200

    except Exception as e:
        return jsonify({
            "success": False, 
            "error": "Failed to generate recommendations.", 
            "details": str(e)
        }), 500


@api_bp.route('/history', methods=['GET'])
def get_history():
    """
    GET /api/history
    Returns all previous searches ordered by recency.
    """
    try:
        searches = RecommendationSearch.query.order_by(RecommendationSearch.created_at.desc()).all()
        return jsonify({
            "success": True,
            "count": len(searches),
            "history": [s.to_dict() for s in searches]
        }), 200
    except Exception as e:
        return jsonify({"success": False, "error": f"Database error: {str(e)}"}), 500


@api_bp.route('/history/<int:history_id>', methods=['GET'])
def get_history_by_id(history_id):
    """
    GET /api/history/<id>
    Returns specific recommendation search by its ID.
    """
    search_record = RecommendationSearch.query.get(history_id)
    if not search_record:
        return jsonify({"success": False, "error": "Search record not found"}), 404

    return jsonify({"success": True, "search": search_record.to_dict()}), 200


@api_bp.route('/history/<int:history_id>', methods=['DELETE'])
def delete_history_item(history_id):
    """
    DELETE /api/history/<id>
    Deletes specific recommendation search.
    """
    search_record = RecommendationSearch.query.get(history_id)
    if not search_record:
        return jsonify({"success": False, "error": "Search record not found"}), 404

    try:
        db.session.delete(search_record)
        db.session.commit()
        return jsonify({"success": True, "message": "Search history item deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "error": f"Failed to delete record: {str(e)}"}), 500
