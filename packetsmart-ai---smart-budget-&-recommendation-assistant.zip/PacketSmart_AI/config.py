import os
from dotenv import load_dotenv

# Load environment variables from .env file if present
load_dotenv()

class Config:
    """Base application configuration."""
    SECRET_KEY = os.getenv('SECRET_KEY', 'packetsmart-secret-dev-key-change-in-prod')
    
    # SQLite Database URI
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URI', 
        f"sqlite:///{os.path.join(BASE_DIR, 'database', 'packetsmart.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # AI Service Settings
    AI_API_KEY = os.getenv('AI_API_KEY', '')
    AI_MODEL_NAME = os.getenv('AI_MODEL_NAME', 'gemini-1.5-flash')
    
    # Application Constants
    APP_NAME = "PacketSmart AI"
    APP_TAGLINE = "Your Smart Budget & Recommendation Assistant"

class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    AI_API_KEY = "test_dummy_key"

class ProductionConfig(Config):
    DEBUG = False
