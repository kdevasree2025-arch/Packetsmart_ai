# PacketSmart AI
> **Tagline:** Your Smart Budget & Recommendation Assistant

PacketSmart AI is an AI-powered full-stack web application designed to help consumers make intelligent, confident purchasing decisions. By entering an available spending budget, target hardware category, and specific requirements, users receive structured, side-by-side product recommendations, honest pros and cons, strict budget guardrail calculations, and lower-cost alternatives.

---

## Table of Contents

- [1. Key Features](#1-key-features)
- [2. Technology Stack](#2-technology-stack)
- [3. Project Structure](#3-project-structure)
- [4. Installation & Setup](#4-installation--setup)
- [5. Environment Variables Configuration](#5-environment-variables-configuration)
- [6. Running the Application](#6-running-the-application)
- [7. How to Run in VS Code](#7-how-to-run-in-vs-code)
- [8. Running Automated Tests](#8-running-automated-tests)
- [9. REST API Documentation](#9-rest-api-documentation)
- [10. Example User Input & AI Output](#10-example-user-input--ai-output)
- [11. Fallback System](#11-fallback-system)
- [12. Troubleshooting & Common Errors](#12-troubleshooting--common-errors)

---

## 1. Key Features

- **Strict Budget Guardrails:** Classifies recommendations automatically into:
  - `Within Budget` (price $\le$ budget)
  - `Slightly Above Budget` (within 15% of ceiling)
  - `Over Budget` (exceeds budget by >15%)
- **Real-Time Balance Arithmetic:** Computes exact `remaining_budget = user_budget - product_price` so users immediately see their surplus or deficit.
- **Side-by-Side Product Comparison:** Evaluates multiple product recommendations in an interactive comparison matrix.
- **Budget-Friendly Alternatives:** Always supplies a lower-cost option for every primary recommendation.
- **Recommendation Search History:** Saves previous searches and recommendation payloads to SQLite for quick review.
- **Modular Generative AI Service:** Clean separation between the AI service wrapper and recommendation logic.
- **Safe Fallback Catalog:** If the AI API key is missing or the external provider suffers network downtime, the system automatically draws from `data/sample_products.json` so the app never crashes.

---

## 2. Technology Stack

- **Backend:** Python 3.10+, Flask 3.0+
- **Database / ORM:** SQLite 3, Flask-SQLAlchemy 3.1+
- **AI Integration:** Google Gemini API (or compatible Generative AI REST endpoints)
- **Frontend:** HTML5, CSS3 (Modern dark-mode design), JavaScript (ES6+ Fetch API)
- **Testing:** Pytest

---

## 3. Project Structure

```text
PacketSmart_AI/
│
├── app.py                         # Flask application entry point & factory
├── requirements.txt               # Python package dependencies
├── .env.example                   # Template for environment secrets
├── README.md                      # Comprehensive project documentation
├── config.py                      # Development, testing, and production configs
│
├── database/
│   ├── __init__.py                # Package exports
│   ├── models.py                  # SQLAlchemy models (RecommendationSearch)
│   └── database.py                # Database initialization logic
│
├── services/
│   ├── __init__.py                # Package exports
│   ├── ai_service.py              # Generative AI prompt builder & API client
│   └── recommendation_service.py  # Business logic, budget math, and catalog fallback
│
├── routes/
│   ├── __init__.py                # Package exports
│   ├── main_routes.py             # HTML page endpoints (/, /recommendations, /history)
│   └── api_routes.py              # REST API routes (/api/recommend, /api/history)
│
├── templates/
│   ├── index.html                 # Homepage with budget inquiry form
│   ├── recommendations.html       # Product cards & side-by-side comparison
│   ├── history.html               # Previous searches and deletion
│   └── error.html                 # Friendly error page
│
├── static/
│   ├── css/
│   │   └── style.css              # Custom responsive stylesheet
│   └── js/
│       └── script.js              # Client-side form handler & async fetch
│
├── data/
│   └── sample_products.json       # Curated fallback product catalog
│
└── tests/
    ├── test_app.py                # Route & API test suite
    └── test_recommendation.py     # Budget math & fallback logic tests
```

---

## 4. Installation & Setup

### Step 1: Clone or Navigate to the Project Folder
```bash
cd PacketSmart_AI
```

### Step 2: Create a Python Virtual Environment
On macOS / Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

On Windows (Command Prompt):
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

On Windows (PowerShell):
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 5. Environment Variables Configuration

Copy `.env.example` to a new `.env` file:
```bash
cp .env.example .env
```

Edit `.env` with your preferred text editor:
```ini
FLASK_ENV=development
FLASK_DEBUG=1
SECRET_KEY=packetsmart-super-secret-key-replace-me

# Get your free Gemini API key from https://aistudio.google.com/
AI_API_KEY=your_actual_gemini_api_key_here
AI_MODEL_NAME=gemini-1.5-flash

DATABASE_URI=sqlite:///packetsmart.db
```

*Note: If you do not have an API key right now, leave it empty. PacketSmart AI will automatically operate in smart fallback mode using `data/sample_products.json`.*

---

## 6. Running the Application

Ensure your virtual environment is active, then execute:
```bash
python app.py
```

The server will initialize the SQLite database in `database/packetsmart.db` and start listening:
```text
 * Running on http://127.0.0.1:5000
```
Open your browser and navigate to `http://localhost:5000`.

---

## 7. How to Run in VS Code

1. Open VS Code and choose **File > Open Folder...**, then select the `PacketSmart_AI/` directory.
2. Press `Ctrl + Shift + P` (or `Cmd + Shift + P` on Mac) and type:
   `Python: Select Interpreter`
3. Choose your virtual environment interpreter: `./venv/bin/python` or `.\venv\Scripts\python.exe`.
4. Open a new integrated terminal (`Ctrl + ~`) and verify the venv is active:
   ```bash
   python app.py
   ```
5. Alternatively, create `.vscode/launch.json`:
   ```json
   {
     "version": "0.2.0",
     "configurations": [
       {
         "name": "Run PacketSmart AI",
         "type": "debugpy",
         "request": "launch",
         "program": "${workspaceFolder}/app.py",
         "console": "integratedTerminal"
       }
     ]
   }
   ```
   Press `F5` to start debugging.

---

## 8. Running Automated Tests

Run the test suite using `pytest`:
```bash
pytest -v
```

Expected output:
```text
tests/test_app.py::test_homepage_loads PASSED
tests/test_app.py::test_recommend_api_validation_failure PASSED
tests/test_app.py::test_recommend_api_success_with_fallback PASSED
tests/test_app.py::test_history_api PASSED
tests/test_recommendation.py::test_validation_logic PASSED
tests/test_recommendation.py::test_budget_classification_logic PASSED
tests/test_recommendation.py::test_ai_fallback_resilience PASSED
==================== 7 passed in 0.45s ====================
```

---

## 9. REST API Documentation

### 1. Request Recommendations
- **Endpoint:** `POST /api/recommend`
- **Headers:** `Content-Type: application/json`
- **Request Body:**
  ```json
  {
    "budget": 500.0,
    "category": "Smartphones",
    "requirements": "Excellent camera, high battery life, OLED screen",
    "brand_preference": "Samsung"
  }
  ```
- **Response `200 OK`:**
  ```json
  {
    "success": true,
    "data": {
      "budget": 500.0,
      "category": "Smartphones",
      "requirements": "Excellent camera, high battery life, OLED screen",
      "brand_preference": "Samsung",
      "search_id": 1,
      "recommendations": [
        {
          "product_name": "Samsung Galaxy A54 5G",
          "estimated_price": 349.99,
          "budget_status": "Within Budget",
          "remaining_budget": 150.01,
          "features": [
            "6.4-inch 120Hz Super AMOLED",
            "50MP OIS Camera",
            "5000mAh Battery"
          ],
          "pros": ["Vibrant display", "Long battery life"],
          "cons": ["No headphone jack", "25W charging"],
          "reason": "Outstanding mid-range phone well below your $500 ceiling.",
          "alternative": "Google Pixel 7a"
        }
      ]
    }
  }
  ```

### 2. View History
- **Endpoint:** `GET /api/history`
- **Response `200 OK`:**
  ```json
  {
    "success": true,
    "count": 1,
    "history": [
      {
        "id": 1,
        "created_at": "2026-09-25 13:40:00",
        "budget": 500.0,
        "category": "Smartphones",
        "requirements": "Camera and battery",
        "brand_preference": "Samsung",
        "recommendations": { ... }
      }
    ]
  }
  ```

### 3. Delete Search Record
- **Endpoint:** `DELETE /api/history/<id>`
- **Response `200 OK`:**
  ```json
  {
    "success": true,
    "message": "Search history item deleted successfully"
  }
  ```

---

## 10. Example User Input & AI Output

### Example Input:
- **Budget:** `$350`
- **Category:** `Headphones`
- **Requirements:** `Need active noise cancellation for frequent long-haul international flights and podcast listening.`
- **Brand Preference:** `Sony`

### Example Output:
1. **Primary Recommendation:** Sony WH-1000XM5 Premium ANC
   - **Estimated Price:** `$349.99`
   - **Budget Status:** `Within Budget` (`+$0.01 remaining`)
   - **Features:** Industry-leading Dual-Processor ANC, 30-hour battery, LDAC Hi-Res audio.
   - **Pros:** Best-in-class noise isolation for aircraft engines, comfortable ear cushions.
   - **Cons:** Sits right at the ceiling of your budget; does not fold as small as XM4.
   - **Why it Matches:** Perfectly matches your long-haul flight requirement with gold-standard ANC.
   - **Budget Alternative:** Sony WH-CH720N (`$129.99`) for travelers looking to save over `$200`.

---

## 11. Fallback System

If you run PacketSmart AI without an `AI_API_KEY` (or if your API key quota is depleted), the application will automatically enter **Smart Fallback Mode**:
1. It queries `data/sample_products.json`.
2. It filters and ranks products by category and budget proximity.
3. It performs full budget arithmetic (`remaining_budget` and status badges).
4. It displays an informative badge notifying the user that verified curated catalog matches are being displayed.
5. Search records are saved to SQLite identically.

---

## 12. Troubleshooting & Common Errors

| Error | Root Cause | Solution |
|---|---|---|
| `ModuleNotFoundError: No module named 'flask'` | Virtual environment is not activated or dependencies not installed. | Run `source venv/bin/activate` and `pip install -r requirements.txt`. |
| `sqlite3.OperationalError: no such table` | Database tables not created. | The application creates them automatically upon start via `init_db(app)`. Ensure the `database/` folder is writable. |
| `AI Provider network failure` / `Invalid API Key` | `AI_API_KEY` is wrong or internet connection dropped. | PacketSmart AI will automatically fall back to the catalog. Verify your key in `.env`. |
| Port `5000` is already in use (`Address already in use`) | Another background server is occupying port 5000. | Start on a different port: `PORT=5050 python app.py`. |
