import os
from flask import Flask
from config import Config
from database.database import db, init_db
from routes.main_routes import main_bp
from routes.api_routes import api_bp

def create_app(config_class=Config):
    """Application factory for PacketSmart AI."""
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Ensure instance and database directories exist
    db_path = app.config.get('SQLALCHEMY_DATABASE_URI', '')
    if 'sqlite:///' in db_path:
        raw_file_path = db_path.replace('sqlite:///', '')
        dir_name = os.path.dirname(raw_file_path)
        if dir_name and not os.path.exists(dir_name):
            os.makedirs(dir_name, exist_ok=True)

    # Initialize Database
    init_db(app)

    # Register Blueprints
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
