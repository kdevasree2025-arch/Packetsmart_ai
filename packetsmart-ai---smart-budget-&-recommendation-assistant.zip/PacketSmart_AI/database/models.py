from datetime import datetime
import json
from .database import db

class RecommendationSearch(db.Model):
    """Stores user recommendation requests and the AI output."""
    __tablename__ = 'recommendation_searches'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    budget = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    requirements = db.Column(db.Text, nullable=False)
    brand_preference = db.Column(db.String(100), nullable=True)
    recommendations_json = db.Column(db.Text, nullable=False)

    def set_recommendations(self, data):
        """Serializes recommendations list/dict into JSON string."""
        self.recommendations_json = json.dumps(data)

    def get_recommendations(self):
        """Deserializes JSON string into recommendations list/dict."""
        try:
            return json.loads(self.recommendations_json)
        except Exception:
            return []

    def to_dict(self):
        """Converts model instance into serializable dictionary."""
        return {
            "id": self.id,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            "budget": self.budget,
            "category": self.category,
            "requirements": self.requirements,
            "brand_preference": self.brand_preference or "None",
            "recommendations": self.get_recommendations()
        }


class RecommendedItem(db.Model):
    """Optional child table for itemized recommendation querying."""
    __tablename__ = 'recommended_items'

    id = db.Column(db.Integer, primary_key=True)
    search_id = db.Column(db.Integer, db.ForeignKey('recommendation_searches.id', ondelete='CASCADE'), nullable=False)
    product_name = db.Column(db.String(255), nullable=False)
    estimated_price = db.Column(db.Float, nullable=False)
    budget_status = db.Column(db.String(50), nullable=False)
    reason = db.Column(db.Text, nullable=True)
    alternative = db.Column(db.String(255), nullable=True)
