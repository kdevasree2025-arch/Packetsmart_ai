from flask_sqlalchemy import SQLAlchemy

# Global SQLAlchemy instance
db = SQLAlchemy()

def init_db(app):
    """Initializes the database connection with the Flask application."""
    db.init_app(app)
    with app.app_context():
        db.create_all()
